$.ajaxSetup({
    headers: {
        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
    }
});

/* Add to Cart */
function addToCart(product_id, attribute_id) {
    $.post("cart/store", {
        product_id: product_id,
        attribute_id: attribute_id
    }).done(function(data) {
        data = JSON.parse(data);
        if (data.status == "success") {
            //toast
            $("#totalItems_desktop").html(data.total_carts);
            $("#totalItems_mob").html(data.total_carts);

            if (!attribute_id) {
                $("#msg" + product_id).removeClass("display-none");
                $("#cartProductBtn" + product_id).hide();
                // for home page
                $(".owl-item")
                    .find("#homeMsg" + product_id)
                    .removeClass("display-none");
                $(".owl-item")
                    .find("#homeCartProductBtn" + product_id)
                    .hide();
            } else {
                $("#subMsg" + attribute_id).removeClass("display-none");
                $("#cartSubProductBtn" + attribute_id).hide();
                // for home page
                $(".owl-item")
                    .find("#homeSubMsg" + attribute_id)
                    .removeClass("display-none");
                $(".owl-item")
                    .find("#homeCartSubProductBtn" + attribute_id)
                    .hide();
            }
        }
        if (data.total_carts) {
            $(".shop-cart").removeClass("disabledbutton");
            $(".navbar-header")
                .find(".cart-icon")
                .removeClass("disabledbutton");
        }
    });
}
/* Add to Cart */

/*Product Quantity Plus/Minus Start and send to cart */
function updateAddtoCart(cart_id, id) {
    if (id.includes("add")) {
        var $qty = $("#" + id)
            .closest("p")
            .find(".qty");
        var currentVal = parseInt($qty.val());
        $qty.val(currentVal + 1);
    } else if (id.includes("minus")) {
        var $qty = $("#" + id)
            .closest("p")
            .find(".qty");
        var currentVal = parseInt($qty.val());
        if (currentVal > 1) {
            $qty.val(currentVal - 1);
        }
    }

    $.post("/cart/update", {
        cart_id: cart_id,
        product_quantity: $qty.val()
    }).done(function(data) {
        data = JSON.parse(data);
        if (data.status == "success") {
            //toast
            $("#totalItems_desktop").html(data.total_carts);
            $("#totalItems_mob").html(data.total_carts);

            // finding the rowno from the id such add1, add2, minus1 etc.
            var row = id.substring(id.length - 1); //Displaying the last character
            $("#price" + row).html(data.total_unit_price);
            $("#sub-total-tk").html(data.sub_total);
            // location.reload();
        }
    });
}

/*Product Quantity Plus/Minus End */

function cartClose(cartId, delBtnId) {
    var parent = $("#" + delBtnId).parent(); //getting the td of the del button

    $.post("/cart/delete", {
        cart_id: cartId
    }).done(function(data) {
        data = JSON.parse(data);
        if (data.status == "success") {
            //toast
            $("#totalItems_desktop").html(data.total_carts);
            $("#totalItems_mob").html(data.total_carts);
            $("#cart-total").html(data.total_carts);
            $("#sub-total-tk").html(data.sub_total);

            if (!data.total_carts) {
                parent
                    .closest("tr")
                    .parent()
                    .parent()
                    .delay(300)
                    .remove();
                $("#total-cart-paragraph").css({
                    "font-size": "25px",
                    "text-align": "center",
                    padding: "50px 0"
                });
            }
            // not to reload the page, just removing the row from DOM
            parent.slideUp(300, function() {
                parent.closest("tr").remove();
            });
        }
    });
}
// Keep Selected Tab On Page Refresh
$('a[data-toggle="tab"]').on("show.bs.tab", function(e) {
    localStorage.setItem("currentTab", $(e.target).attr("href"));
});
var currentTab = localStorage.getItem("currentTab");
//console.log(currentTab);
if (currentTab) {
    $('a[href="' + currentTab + '"]').tab("show");
}
// Keep Selected Tab On Page Refresh

// Dynamic dropdwon district zone

$('select[name="district"]').on("change", function() {
    var districtId = $(this).val();
    if (districtId) {
        $.ajax({
            url: "/checkout/zones/" + districtId,
            type: "GET",
            dataType: "json",
            success: function(data) {
                $('select[name="zone"]').empty();
                $.each(data, function(key, value) {
                    $('select[name="zone"]').append(
                        '<option value="' + key + '">' + value + "</option>"
                    );
                });
            }
        });
    } else {
        $('select[name="zone"]').empty();
    }
});
