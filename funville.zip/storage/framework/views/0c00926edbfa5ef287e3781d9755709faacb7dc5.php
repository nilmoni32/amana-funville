<!DOCTYPE html>
<html lang="en">
<style>
    table,
    th,
    td {
        border: 1px solid black;
    }

    /* make the table a 100% wide by default */
    table {
        width: 100%;
    }

    /* if the browser window is at least 800px-s wide: */
    @media  screen and (min-width: 800px) {
        table {
            width: 80%;
        }
    }

    /* if the browser window is at least 1000px-s wide: */
    @media  screen and (min-width: 1000px) {
        table {
            width: 60%;
        }
    }
</style>

<body>

    <p>Dear Concern,</p>
    <p>Please find the following ingredient lists need to be purchased for <?php echo e(config('app.name')); ?> Restaurant.</p>
    <br>
    <table style=" background-repeat:no-repeat;margin:0;" cellpadding="0" cellspacing="0">
        <thead>
            <tr>
                <th style="height:40px; width:400px; margin:0;">#</th>
                <th style="height:40px; width:400px; margin:0;">Ingredient Name</th>
                <th style="height:40px; width:400px; margin:0;">Stock Qty</th>
                <th style="height:40px; width:400px; margin:0;">Alert Qty</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="height:40px; width:400px; margin:0; text-align:center;"><?php echo e($loop->index + 1); ?></td>
                <td style="height:40px; width:400px; margin:0; text-align:center;"><?php echo e($ingredient->name); ?></td>
                <td style="height:40px; width:400px; margin:0; text-align:center;"><?php echo e($ingredient->total_quantity); ?>

                </td>
                <td style="height:40px; width:400px; margin:0; text-align:center;"><?php echo e($ingredient->alert_quantity); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <p></p>
    <span>Thanks</span>,<br />
    <p><?php echo e(config('app.name')); ?> auto generated mail</p>

</body>

</html><?php /**PATH D:\xampp\htdocs\funville\resources\views/mail/email/ingredientUpdate.blade.php ENDPATH**/ ?>