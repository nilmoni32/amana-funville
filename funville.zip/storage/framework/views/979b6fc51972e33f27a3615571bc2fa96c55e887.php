<!-- product display -->
<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php $attributeCheck = in_array($product->id, $product->attributes->pluck('product_id')->toArray())
    ?>
    <?php if(!($attributeCheck) && $product->status): ?>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
        <div class="dish-menu">
            <div class="item">
                <div class="box">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                        class="img-responsive" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="caption">
                        <h4><?php echo e($product->name); ?></h4>
                        
                        <?php if($product->discount_price): ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->discount_price,0)); ?>

                        </p>
                        <span
                            style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></span>
                        
                        <span>
                            -<?php echo e(round(($product->price - $product->discount_price)*100/$product->price, 0)); ?>%</span>
                        <?php else: ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></p>
                        <?php endif; ?>
                        <span class="text-left pt-1 d-block"><?php echo e($product->description); ?></span>

                    </div>
                    <div class="cart-overlay" onclick="addToCart(<?php echo e($product->id); ?>, 0)">
                        <h5>Add to Cart</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php elseif($attributeCheck && $product->status): ?>
    
    <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
        <div class="dish-menu">
            <div class="item">
                <div class="box">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                        class="img-responsive" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="caption">
                        <h4><?php echo e($product->name); ?>-(<?php echo e($attribute->size); ?>)</h4>
                        
                        <?php if($attribute->special_price): ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->special_price,0)); ?>

                        </p>
                        <span
                            style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></span>
                        
                        <span>
                            -<?php echo e(round(($attribute->price - $attribute->special_price)*100/$attribute->price, 0)); ?>%</span>
                        <?php else: ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></p>
                        <?php endif; ?>
                        <span class="text-left pt-1 d-block"><?php echo e($product->description); ?></span>
                    </div>
                    <div class="cart-overlay" onclick="addToCart(<?php echo e($product->id); ?>, <?php echo e($attribute->id); ?>)">
                        <h5>Add to Cart</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="pt-4">
    <?php echo e($products->links()); ?>

</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/productview.blade.php ENDPATH**/ ?>