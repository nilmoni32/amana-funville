<!-- product display -->
<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php $attributeCheck = in_array($product->id, $product->attributes->pluck('product_id')->toArray())
    ?>
    
    <?php if(!($attributeCheck) && $product->status): ?>
    <div class="col-md-4 col-sm-6 col-xs-12 mb-3">
        <div class="dish-menu">
            <div class="item">
                <div class="box">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                        class="img-responsive" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="caption">
                        <h4><?php echo e($product->name); ?></h4>
                        
                        <?php if($product->discount_price): ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->discount_price,0)); ?>

                        </p>
                        <span
                            style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></span>
                        
                        <span>
                            -<?php echo e(round(($product->price - $product->discount_price)*100/$product->price, 0)); ?>%</span>
                        <?php else: ?>
                        <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></p>
                        <?php endif; ?>
                        <span class="text-left px-1 pt-1 d-block"><?php echo e($product->description); ?></span>

                    </div>
                    
            </div>
            <div class="hoverbox pb-2">
                <?php
                //Checking the product is added to cart or not
                if(Auth::check()){ //Auth::check() to check if the user is logged in
                // when logged user adds products to cart.
                $cart = App\Models\Cart::where('user_id', Auth::id())
                ->where('product_id', $product->id)
                ->where('order_id', NULL)
                ->where('has_attribute', 0)
                ->first();
                }else{
                // when a guest adds product to cart.
                $cart = App\Models\Cart::where('ip_address', request()->ip())
                ->where('product_id', $product->id)
                ->where('has_attribute', 0)
                ->first();
                }
                ?>
                <button class="btn btn-theme-alt btn-cart btn-block <?php echo e($cart ? 'display-none' : ''); ?>"
                    id="cartProductBtn<?php echo e($product->id); ?>" onclick="addToCart(<?php echo e($product->id); ?>, 0)">Add to
                    Cart</button>
                <p class="<?php echo e($cart ? '' : 'display-none'); ?> cart-msg" id="msg<?php echo e($product->id); ?>">
                    Food is added to Cart</p>
            </div>
        </div>
    </div>
</div>
<?php elseif($attributeCheck && $product->status): ?>

<?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-4 col-sm-6 col-xs-12 mb-3">
    <div class="dish-menu">
        <div class="item">
            <div class="box">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                    class="img-responsive" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="caption">
                    <h4><?php echo e($product->name); ?>-(<?php echo e($attribute->size); ?>)</h4>
                    
                    <?php if($attribute->special_price): ?>
                    <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->special_price,0)); ?>

                    </p>
                    <span
                        style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></span>
                    
                    <span>
                        -<?php echo e(round(($attribute->price - $attribute->special_price)*100/$attribute->price, 0)); ?>%</span>
                    <?php else: ?>
                    <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></p>
                    <?php endif; ?>
                    <span class="text-left px-1 py-1 d-block"><?php echo e($product->description); ?></span>

                </div>
                
        </div>
        <div class="hoverbox pb-2">
            <?php
            //Checking the product is added to cart or not
            if(Auth::check()){ //Auth::check() to check if the user is logged in
            // when logged user adds products to cart.
            $cart = App\Models\Cart::where('user_id', Auth::id())
            ->where('product_id', $product->id)
            ->where('product_attribute_id', $attribute->id)
            ->where('order_id', NULL)
            ->where('has_attribute', 1)
            ->first();
            }else{
            // when a guest adds product to cart.
            $cart = App\Models\Cart::where('ip_address', request()->ip())
            ->where('product_id', $product->id)
            ->where('product_attribute_id', $attribute->id)
            ->where('has_attribute', 1)
            ->first();
            }
            ?>
            <button class="btn btn-theme-alt btn-cart btn-block <?php echo e($cart ? 'display-none' : ''); ?>"
                id="cartSubProductBtn<?php echo e($attribute->id); ?>"
                onclick="addToCart(<?php echo e($product->id); ?>, <?php echo e($attribute->id); ?>)">Add
                to Cart</button>
            <p class="<?php echo e($cart ? '' : 'display-none'); ?> cart-msg" id="subMsg<?php echo e($attribute->id); ?>">
                Food is added to Cart</p>

        </div>
    </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="pt-4">
    <?php echo e($products->links()); ?>

</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/productview.blade.php ENDPATH**/ ?>