<!--  Header Start  -->
<header>
    <!--Top Header Start -->
    <div class="top">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-xs-12">
                    <ul class="list-inline float-left icon">
                        <li class="list-inline-item"><a href="#"><i class="icofont icofont-phone"></i> Hotline :
                                <?php echo e(config('settings.phone_no')); ?></a></li>
                    </ul>
                    <ul class="list-inline float-right icon">
                        <li class="list-inline-item"><a href="shopping-cart.html"><i
                                    class="icofont icofont-cart-alt"></i> Cart</a></li>
                        <li class="list-inline-item dropdown">
                            <?php if(auth()->guard()->guest()): ?><a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i
                                    class="icofont icofont-ui-user"></i> My Account</a>
                            <ul class="dropdown-menu dropdown-menu-right drophover" aria-labelledby="dropdownMenuLink">
                                <li class="dropdown-item"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li class="dropdown-item"><a href="<?php echo e(route('register')); ?>">Register</a></li>
                            </ul>
                            <?php else: ?>
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                    style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                            <?php endif; ?>

                        </li>
                        <!-- Header Social Start -->
                        <li class="list-inline-item">
                            <ul class="list-inline social">
                                <li class="list-inline-item"><a href="<?php echo e(config('settings.social_facbook')); ?>"
                                        target="_blank"><i class="icofont icofont-social-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="<?php echo e(config('settings.social_twitter')); ?>"
                                        target="_blank"><i class="icofont icofont-social-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="<?php echo e(config('settings.social_instagram')); ?>"
                                        target="_blank"><i class="icofont icofont-social-instagram"></i></a>
                                </li>
                                <li class="list-inline-item"><a href="<?php echo e(config('settings.social_youtube')); ?>"
                                        target="_blank"><i class="icofont icofont-social-youtube-play"></i></a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <!-- Header Social End -->
                </div>
            </div>
        </div>
    </div>
    <!--Top Header End -->
    <div class="sticky">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <!-- Logo Start  -->
                    <div id="logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <img id="logo_img" class="img-fluid"
                                src="<?php echo e(asset('storage/'.config('settings.site_logo'))); ?>" alt="logo"
                                title="logo" /></a>
                    </div>
                    <!-- Logo End  -->
                </div>

                <div class="col-md-7 col-sm-6 col-xs-12 paddleft">
                    <?php echo $__env->make('site.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-md-3 col-sm-12 col-xs-12 paddleft mt-3">
                    <form action="#" class="form-horizontal search-icon" method='post'>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for foods" name="s">
                            <div class="input-group-append">
                                <button class="btn btn-theme" type="submit">
                                    <i class="icofont icofont-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Header End   --><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/header.blade.php ENDPATH**/ ?>