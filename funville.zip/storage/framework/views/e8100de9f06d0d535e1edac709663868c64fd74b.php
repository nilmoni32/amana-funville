<?php $__env->startSection('title', 'Reservation'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Reservation</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">Reservation</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->
<div class="reservation no-bg coffee">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 commontop text-center">
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-block bg-success text-white mt-3">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('success')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-error alert-block bg-danger text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('error')); ?></strong>
                </div>
                <?php endif; ?>
            </div>
            <!-- Title Content Start -->
            <div class="col-sm-12 commontop text-center mb-2">
                <h4 class="text-center"><?php echo e(__('Book Your Table')); ?></h4>
                <div class="divider style-1 center">
                    <span class="hr-simple left"></span>
                    <i class="icofont icofont-ui-press hr-icon"></i>
                    <span class="hr-simple right"></span>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <p class="mt-3 mx-3">
                            <?php echo e(__("We look forward to serving you delicious, healthy and quality food. Let's start  online booking at the Funville Restaurant of your choice. 
                        If you wish to make a reservation for a larger party please contact us on the number below, we also accept walk-ins.")); ?>

                        </p>
                    </div>
                    <div class="col-sm-12">
                        <a href="" class="btn btn-theme-alt"><i class="icofont icofont-phone"></i>
                            <?php echo e(config('settings.phone_no')); ?> </li></a>
                    </div>
                    <div class="offset-md-2"></div>
                    <div class="col-md-8 col-xs-12 mt-5">
                        <!-- Reservation Form Start -->
                        <form action="<?php echo e(route('reservation.post.mail')); ?>" method="POST" class="row" role="form">
                            <?php echo csrf_field(); ?>
                            <div class="form-group col-sm-6">
                                <input name="fname" placeholder="First name" id="fname"
                                    class="form-control <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" required>
                                <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-sm-6">
                                <input name="lname" placeholder="Last name" id="lname"
                                    class="form-control <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" required>
                                <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-sm-6">
                                <input name="email" placeholder="Your email" id="email"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-sm-6">
                                <input name="mobile" placeholder="Phone Number" id="mobile"
                                    class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" required>
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group col-sm-6">
                                <input name="appointment_dt" placeholder="Select Date & Time" id="date"
                                    class="form-control datetimepicker" type="text" required>
                            </div>
                            <div class="form-group col-sm-6">
                                <input name="persons" placeholder="Number of persons" id="persons" class="form-control"
                                    type="number" required>
                            </div>
                            <div class="form-group col-xs-12 col-md-12">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-theme btn-wide">book now</button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <div class="offset-md-2"></div>

                </div>
            </div>
        </div>
    </div>
</div>





<!-- Fun-Factor Start -->
<div class="fun-factor">
    <div class="container">
        <div class="row ">
            <div class="col-sm-3 col-6">
                <!-- Fun-Factor Box Start -->
                <div class="single-box">
                    <span>
                        <i class="icofont icofont-spoon-and-fork"></i>
                    </span>
                    <h4 class="number" data-from="100" data-to="300" data-refresh-interval="10">100</h4>
                    <h3>MENU ITEMS</h3>
                </div>
                <!-- Fun-Factor Box End -->
            </div>
            <div class="col-sm-3 col-6">
                <!-- Fun-Factor Box Start -->
                <div class="single-box">
                    <span>
                        <i class="icofont icofont-emo-simple-smile"></i>
                    </span>
                    <h4 class="number" data-from="50" data-to="400" data-refresh-interval="10">50</h4>
                    <h3>VISITOR EVERYDAY</h3>
                </div>
                <!-- Fun-Factor Box End -->
            </div>
            <div class="col-sm-3 col-6">
                <!-- Fun-Factor Box Start -->
                <div class="single-box">
                    <span>
                        <i class="icofont icofont-waiter-alt"></i>
                    </span>
                    <h4 class="number" data-from="1" data-to="40" data-refresh-interval="10">1</h4>
                    <h3>EXPERT CHEF</h3>
                </div>
                <!-- Fun-Factor Box End -->
            </div>
            <div class="col-sm-3 col-6">
                <!-- Fun-Factor Box Start -->
                <div class="single-box">
                    <span>
                        <i class="icofont icofont-heart-alt"></i>
                    </span>
                    <h4 class="number" data-from="10" data-to="100" data-refresh-interval="10">10</h4>
                    <h3>TEST & LOVE</h3>
                </div>
                <!-- Fun-Factor Box End -->
            </div>
        </div>
    </div>
</div>
<!-- Fun-Factor End -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<script>
    $(document).ready(function () {
      $('.datetimepicker').datetimepicker({
        timepicker:true,
        datepicker:true,        
        format: 'd-m-Y H:i a',
        step:30,
        ampm: true,
        hours12:false,        
      });
      $(".datetimepicker").attr("autocomplete", "off");
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/reservation.blade.php ENDPATH**/ ?>