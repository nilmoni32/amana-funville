<!DOCTYPE html>
<html lang="en">

<body>
    <h3>Customer Details:</h3>
    <p>Name: <?php echo e($user['name']); ?> <br /><br />
        Email: <?php echo e($user['email']); ?> <br /><br />
        Phone:<?php echo e($user['mobile']); ?> <br /><br />
    </p>
    <p>Dear Concern,</p>
    <p><?php echo e($user['enquiry']); ?></p>

    <p>You can reach me using the contact information listed above.</p>

    <p>Thank you.</p>

    <p>Sincerely,</p>
    <p><?php echo e($user['name']); ?></p>


</body>

</html><?php /**PATH D:\xampp\htdocs\funville\resources\views/mail/email/contactus.blade.php ENDPATH**/ ?>