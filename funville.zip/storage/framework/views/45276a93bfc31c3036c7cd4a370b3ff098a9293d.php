<div class="modal fade" id="userCartModal<?php echo e($order->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-center border-bottom-0 pb-0">
                <h5 class="modal-title text-right mt-3" id="exampleModalLabel"><i class="fa fa-shopping-basket"></i>
                    Customer POS Order Details
                </h5>
            </div>
            <div class="modal-body text-center">
                <p class="text-center h6 mt-2">[ Order Number:&nbsp;
                    <?php echo e($order->order_number); ?> ]</p>
                <p class="text-center h6 py-2">[ Payment Details:&nbsp;
                    <?php if($order->cash_pay): ?><span>Cash:
                        <?php echo e(round($order->cash_pay,2)); ?> <?php echo e(config('settings.currency_symbol')); ?></span><?php endif; ?>
                    <?php if($order->card_pay): ?><span>, Card:
                        <?php echo e(round($order->card_pay,2)); ?> <?php echo e(config('settings.currency_symbol')); ?></span><?php endif; ?>
                    <?php if($order->mobile_banking_pay): ?><span>, Mobile Banking:
                        <?php echo e(round($order->mobile_banking_pay,2)); ?> <?php echo e(config('settings.currency_symbol')); ?></span><?php endif; ?>
                    ]</p>
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <th>#</th>
                        <th>Food Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </thead>
                    <tbody>
                        <?php $subtotal = 0; $cart_model = 'App\Models\Sale'; ?>
                        <?php if($order->status == 'delivered' || $order->status == 'cancel' ): ?>
                        <?php $cart_model = 'App\Models\Salebackup';?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $cart_model::where('ordersale_id',
                        $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posCart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td class="text-left" style="text-transform:capitalize">
                                <img src="<?php echo e(asset('storage/'.$posCart->product->images->first()->full)); ?>"
                                    title="<?php echo e($posCart->product->name); ?>" class="img-responsive pr-2 rounded"
                                    width="70px" />
                                <?php echo e($posCart->product->name); ?>

                            </td>
                            <td class="text-center">
                                <?php echo e($posCart->product_quantity); ?>

                            </td>
                            <td class="text-center" style="text-transform:capitalize">
                                <?php if($posCart->product->discount_price): ?>
                                <?php echo e(round($posCart->product->discount_price,2)); ?>

                                <?php else: ?>
                                <?php echo e(round($posCart->product->price,2)); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-center" style="text-transform:capitalize">
                                <?php if($posCart->product->discount_price): ?>
                                <?php echo e(round( ($posCart->product->discount_price * $posCart->product_quantity), 2)); ?>

                                <?php $subtotal += $posCart->product->discount_price * $posCart->product_quantity;
                                ?>
                                <?php else: ?>
                                <?php echo e(round( ($posCart->product->price * $posCart->product_quantity),2)); ?>

                                <?php $subtotal += $posCart->product->price * $posCart->product_quantity; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5">
                                <p class="text-right my-2 ">Subtotal:
                                    <?php echo e(round($subtotal,2)); ?> <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <?php if(config('settings.tax_percentage')): ?>
                                <p class="text-right my-2 ">Vat (<?php echo e(config('settings.tax_percentage')); ?>%):
                                    <?php echo e(round($subtotal* (config('settings.tax_percentage')/100),2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <?php endif; ?>
                                <p class="text-right my-2 ">Order Total:
                                    <?php echo e(round( ($subtotal + $subtotal * (config('settings.tax_percentage')/100)), 2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <p class="text-right my-2 ">Discount:
                                    <?php if($order->discount): ?>
                                    <?php echo e(round($order->discount,2)); ?> <?php echo e(config('settings.currency_symbol')); ?>

                                    <?php else: ?>
                                    <?php echo e(config('settings.currency_symbol')); ?>

                                    <?php endif; ?>
                                </p>
                                <p class="text-right my-2 ">Reward Point Discount:
                                    <?php if($order->reward_discount): ?>
                                    <?php echo e(round($order->reward_discount,2)); ?> <?php echo e(config('settings.currency_symbol')); ?>

                                    <?php else: ?>
                                    <?php echo e(config('settings.currency_symbol')); ?>

                                    <?php endif; ?>
                                </p>
                                <p class="text-right mb-0 h6 mt-2">
                                    Due Amount:
                                    <?php echo e(round($order->grand_total,2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class=" modal-footer border-top-0">
                <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div><?php /**PATH /var/www/amanafunville.com/html/resources/views/admin/sales/orders/includes/userCart.blade.php ENDPATH**/ ?>