<!-- Main Menu Start  -->
<div id="menu">
    <nav class="navbar navbar-expand-md">
        <div class="navbar-header">
            <span class="menutext d-block d-md-none"><a href="<?php echo e(url('/')); ?>"><img class="img-fluid"
                        src="<?php echo e(asset('frontend/images/funville.png')); ?>" alt="Funville" style="max-height:25px;"></a>
                <a href="<?php echo e(route('cart.index')); ?>" class="btn-sm float-right text-white" style="margin:0 auto"><i
                        class="icofont icofont-cart-alt h5"></i>(<span
                        id="totalItems_mob"><?php echo e(App\Models\Cart::totalItems()); ?></span>)</a>
            </span>

            <button data-target=".navbar-ex1-collapse" data-toggle="collapse" class="btn btn-navbar navbar-toggler"
                type="button"><i class="icofont icofont-navigation-menu"></i></button>
        </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse padd0">
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="nav-item"><a href="<?php echo e(route('about')); ?>">About us</a></li>
                <li class="nav-item"><a href="<?php echo e(route('products.index')); ?>">Food Menu</a></li>
                <li class="nav-item"><a href="<?php echo e(route('reservation')); ?>">Reservation</a></li>
                <li class="nav-item"><a href="<?php echo e(route('contact')); ?>">contact us</a></li>
            </ul>
        </div>
    </nav>
</div>
<!-- Main Menu End --><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/nav.blade.php ENDPATH**/ ?>