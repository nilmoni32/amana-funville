<!-- Main Menu Start  -->
<div id="menu">
    <nav class="navbar navbar-expand-md">
        <div class="navbar-header">
            <span class="menutext d-block d-md-none"><img class="img-fluid"
                    src="<?php echo e(asset('frontend/images/funville.png')); ?>" alt="Funville" style="max-height:25px;"></span>
            <button data-target=".navbar-ex1-collapse" data-toggle="collapse" class="btn btn-navbar navbar-toggler"
                type="button"><i class="icofont icofont-navigation-menu"></i></button>
        </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse padd0">
            <ul class="nav navbar-nav ml-auto">
                <li class="nav-item"><a href="index-2.html">Home</a></li>
                <li class="nav-item"><a href="about.html">About us</a></li>
                <li class="nav-item"><a href="menu.html">Food Menu</a></li>
                <li class="nav-item"><a href="reservation.html">Reservation</a></li>
                <li class="nav-item"><a href="contact-us-2.html">contact us</a></li>
            </ul>
        </div>
    </nav>
</div>
<!-- Main Menu End --><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/nav.blade.php ENDPATH**/ ?>