
<?php $__env->startSection('title'); ?> <?php echo e($subTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-modx"></i> <?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-3">
        <div class="tile p-0">
            <?php echo $__env->make('admin.recipes.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col-md-9">
        <div class="tile">
            <div class="tile-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Ingredient Name </th>
                            <th class="text-center"> Qty </th>
                            <th class="text-center"> P.U Cost </th>
                            <th class="text-center"> Total Cost </th>
                            <th class="text-center text-danger"><i class="fa fa-bolt"> </i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recipeIngredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipeIngredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($loop->index + 1); ?>

                            </td>
                            <td style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php if($recipeIngredient->ingredient->pic): ?>
                                <img src="<?php echo e(asset('/storage/images/'. $recipeIngredient->ingredient->pic)); ?>" width="40"
                                    class="mr-1">
                                <?php endif; ?>
                                <?php echo e($recipeIngredient->ingredient->name); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($recipeIngredient->quantity); ?> <?php echo e($recipeIngredient->measure_unit); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($recipeIngredient->unit_price); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($recipeIngredient->ingredient_total_cost); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <a href="<?php echo e(route('admin.recipe.ingredient.edit', $recipeIngredient->id)); ?>"
                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('admin.recipe.ingredient.delete', $recipeIngredient->id)); ?>"
                                        class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\funville\resources\views/admin/recipes/ingredients/index.blade.php ENDPATH**/ ?>