
<?php $__env->startSection('title'); ?> <?php echo e($subTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-th"></i> <?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <a href="<?php echo e(route('admin.ingredient.create')); ?>" class="btn btn-primary pull-right">Add Ingredient</a>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Name </th>
                            <th class="text-center"> Category</th>
                            <th class="text-center"> Stock Unit</th>
                            <th class="text-center"> Qty </th>
                            <th class="text-center"> Price </th>
                            <th class="text-center"> Alert Qty </th>
                            <th class="text-center"> Small Unit</th>
                            <th class="text-center"> S.U. Cost</th>
                            <th class="text-center text-danger"><i class="fa fa-bolt"> </i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($loop->index + 1); ?>

                            </td>
                            <td style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php if($ingredient->pic): ?>
                                <img src="<?php echo e(asset('/storage/images/'. $ingredient->pic)); ?>" width="40" class="mr-1">
                                <?php endif; ?>
                                <?php echo e($ingredient->name); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <span class="badge badge-info"><?php echo e($ingredient->typeingredient->name); ?></span>
                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->measurement_unit); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->total_quantity); ?> <?php echo e($ingredient->measurement_unit); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->total_price); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->alert_quantity); ?> <?php echo e($ingredient->measurement_unit); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->smallest_unit); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($ingredient->smallest_unit_price); ?></td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <a href="<?php echo e(route('admin.ingredient.edit', $ingredient->id)); ?>"
                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('admin.ingredient.delete', $ingredient->id)); ?>"
                                        class="btn btn-sm btn-danger <?php echo e(App\Models\IngredientPurchase::where('ingredient_id', $ingredient->id)->count()
                                            ? 'disabled' :''); ?>"><i class="fa fa-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $('#sampleTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/ingredients/index.blade.php ENDPATH**/ ?>