
<?php $__env->startSection('title', 'Shopping cart'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Checkout</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">Checkout</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->
<!-- Cart Start  -->
<div class="mycart">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <?php if(session('error')): ?>
                <div class="alert alert-error alert-block bg-danger text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('error')); ?></strong>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <form action="<?php echo e(route('checkout.place.order')); ?>" method="POST" role="form">
            <?php echo csrf_field(); ?>
            <div class="row" id="tab-info">
                <div class="col-lg-7 col-md-8 col-12 pb-5">
                    <h6 class="card-title mt-2">Billing Details</h6>
                    <fieldset>
                        <div class="form-group">
                            <label>Full name:</label>
                            <input name="name" value="<?php echo e(auth()->user()->name); ?>" id="name"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Email Address:</label>
                            <input name="email" value="<?php echo e(auth()->user()->email); ?>" placeholder="Email" id="email"
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Phone Number:</label>
                            <input name="phone_no" value="<?php echo e(auth()->user()->phone_number); ?>" id="phone_no"
                                class="form-control  <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" required>
                            <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-row">
                            <div class="col form-group">
                                <label>Select District:</label>
                                <select class="form-control <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="district"
                                    id="district" required>
                                    <option selected='false' value="">---District---</option>
                                    <?php $__currentLoopData = App\Models\District::where('status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="col form-group">
                                <label>Select Area:</label>
                                <select name="zone" class="form-control <?php $__errorArgs = ['zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option selected='false' value="">---Area---</option>
                                </select>
                                <?php $__errorArgs = ['zone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <label>Shipping Address:</label>
                            <textarea class="form-control <?php $__errorArgs = ['address_txt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address_txt"
                                name="address_txt" style="height:70px;" required></textarea>
                            <div class="links" style="margin-top:-10px;">
                                <label><input type="checkbox" class="checkbox-inline" id="address_chk"
                                        name="address_chk"> Use default address for my shipping Address? </label>
                            </div>
                            <?php $__errorArgs = ['address_txt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <h6 class="text-danger mt-5 mb-3">We are delivering order 11:59 AM to 9:00 PM Only. If your
                            order after 9:00 PM, It will be processed for next day.</h6>
                        <div class="form-group">
                            <label>Current Date & Time :</label>
                            <p><?php echo e(\Carbon\Carbon::now()); ?></p>
                        </div>
                        <div class="form-group">
                            <label>Delivery Date & Time :</label>
                            <?php
                            $time = \Carbon\Carbon::now();
                            $morning = \Carbon\Carbon::create($time->year, $time->month, $time->day, 0, 0, 0);
                            $evening = \Carbon\Carbon::create($time->year, $time->month, $time->day, 21, 0, 0);
                            if($time->between($morning, $evening, true)) {
                            $deliver_time = $time->toDateString();
                            }else{
                            $tom = \Carbon\Carbon::tomorrow();
                            $deliver_time = $tom->toDateString();
                            }
                            ?>
                            <p><?php echo e($deliver_time); ?></p>
                            <input type="hidden" value="<?php echo e($deliver_time); ?>" name="delivery_timings">
                        </div>
                    </fieldset>
                </div>
                <div class="col-lg-1 d-none d-lg-block"></div>
                <div class="col-lg-4 col-md-4 col-12">
                    <div class="card">
                        <div class="card-header align-middle">
                            <h5 class="text-center">Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                    <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($cart->has_attribute): ?>
                                            
                                            <?php echo e($cart->product->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->size); ?>)
                                            x <?php echo e($cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e($cart->product->name); ?> x <?php echo e($cart->product_quantity); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="px-0">
                                            <?php if($cart->has_attribute): ?>
                                            
                                            
                                            <?php if(
                                            App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price): ?>
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price,0) *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->price,0) *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($cart->product->discount_price): ?>
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(round($cart->product->discount_price,0) *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(round($cart->product->price,0) *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>Subtotal</td>
                                        <?php $subtotal = App\Models\Cart::calculateSubtotal(); ?>
                                        <td class="px-0">
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e($subtotal); ?></td>
                                    </tr>
                                    <?php if(config('settings.tax_percentage')): ?>
                                    <tr>
                                        <td>Vat Percentage (<?php echo e(config('settings.tax_percentage')); ?>%)</td>
                                        <td class="px-0">
                                            <?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(round($subtotal * (config('settings.tax_percentage')/100),0)); ?>

                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td>Shipping Cost</td>
                                        <td class="px-0"><?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e(config('settings.delivery_charge')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Order Total</td>
                                        <td class="px-0"><?php echo e(config('settings.currency_symbol')); ?>

                                            <?php echo e($subtotal + config('settings.delivery_charge') + ($subtotal* (config('settings.tax_percentage')/100))); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="form-group">
                        <?php if(App\Models\Cart::totalCarts()->count()): ?>
                        <input type="submit" value="Place Order" class="btn btn-theme btn-md btn-block mt-5 mb-5" />
                        <?php else: ?>
                        <input type="submit" value="Place Order"
                            class="btn btn-theme btn-md btn-block mt-5 mb-5 disabled" />
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Cart End  -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    // var $tb = $("#address_txt");

    $(function() { 
        $('form').submit(function(){
            $(this).find('input[type=submit]').prop('disabled', true);
        });

        $('input[name="address_chk"]').on("change", function () {       
            if (this.checked) {
                $.ajax({
                url: "/checkout/user/address/",
                type: "GET",
                dataType: "json",
                success: function(data) {               
                    if (data.status == "success") {                    
                    $('textarea[name="address_txt"]').html(data.address); 
                    }
                    }
                });
            }else{
                $('textarea[name="address_txt"]').html("");
            }
        });
    });
   


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/checkout.blade.php ENDPATH**/ ?>