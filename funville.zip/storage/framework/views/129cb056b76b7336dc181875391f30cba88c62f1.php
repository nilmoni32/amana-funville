
<?php $__env->startSection('title', 'Checkout'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Checkout</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">Checkout</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->
<div class="mycart">
    <div class="container paycard">
        <div class="row">
            <div class="offset-md-1"></div>
            <div class="col-md-10 col-12 text-center">
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-block bg-success text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('success')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-error alert-block bg-danger text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('error')); ?></strong>
                </div>
                <?php endif; ?>
            </div>
            <div class="offset-md-1"></div>
        </div>
        <div class="row">
            <div class="col-12 pb-5">
                <h5 class="card-title text-center mb-2">Order Number:
                    <?php echo e($order->order_number); ?></h5>
                <p class="text-center pt-0 font-weight-bold">Your order is on its way, please pay with <span
                        class="cash-btn"> Cash</span> on delivery
                    
                </p>
            </div>
        </div>
        <div class="row">
            <div class="offset-md-2"></div>
            <div class="col-md-8 col-12 mb-5">
                <div class="card">
                    <p class="text-center py-3">Do you want to <span class="text-success font-weight-bold h5">pay
                            now?</span></p>
                    <div class="card-body px-5">
                        <ul class="list-inline text-center link pb-4">
                            <li class="list-inline-item">
                                <small>All Bangladeshi credit/debit card</small><br>
                                <form action="<?php echo e(url('/checkout/order/payment')); ?>" method="POST"
                                    class="needs-validation">
                                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                                    <input type="hidden" value="<?php echo e($order->id); ?>" name="id" />
                                    <button class="btn btn-theme-alt my-2" type="submit"><img
                                            src="<?php echo e(asset('frontend')); ?>/images/payment.png" alt="visa"
                                            title="Bangladeshi credit/debit card" class="img-fluid"
                                            width="150px"></button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="offset-md-2"></div>
        </div>
        <div class="row">
            <div class="offset-md-2"></div>
            <div class="col-md-8 col-12 mb-5">
                <div class="row">
                    <div class="col-md-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header text-center">
                                Delivery Date & Address
                            </div>
                            <div class="card-body text-center">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($order->address); ?></td>
                                        </tr>
                                        <tr>
                                            <?php
                                            $time = strtotime($order->order_date);
                                            $date = date('Y-m-d', $time); ?>
                                            <td class="text-center">Order Date: <span class="ml-5"><?php echo e($date); ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <?php
                                            $time = strtotime($order->delivery_date);
                                            $date = date('Y-m-d', $time); ?>
                                            <td class="text-center">Delivery Date: <span class="ml-5"><?php echo e($date); ?></span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header text-center">
                                Order Summary
                            </div>
                            <div class="card-body text-center">
                                <table class="table table-borderless">
                                    <?php $subtotal = ($order->grand_total - config('settings.delivery_charge'))/(1+
                                    (config('settings.tax_percentage')/100)) ?>
                                    <tbody>
                                        <tr>
                                            <td class="text-left">Subtotal</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e($subtotal); ?>

                                            </td>
                                        </tr>
                                        <?php if(config('settings.tax_percentage')): ?>
                                        <tr>
                                            <td class="text-left">Vat (<?php echo e(config('settings.tax_percentage')); ?>%)</td>
                                            <td class="text-left">
                                                <?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(round($subtotal * (config('settings.tax_percentage')/100),0)); ?>

                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td class="text-left">Shipping Cost</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(config('settings.delivery_charge')); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">Order Total</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(round($order->grand_total,0)); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="offset-md-2"></div>
        </div>
        




</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/amanafunville.com/html/resources/views/site/pages/payment.blade.php ENDPATH**/ ?>