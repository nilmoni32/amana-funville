<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-users"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfdaily')); ?>" class="btn btn-sm btn-dark" target="_blank"><i
                class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="<?php echo e(route('admin.reports.exceldaily')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-file-excel-o"
                style="font-size:16px;"></i></a>

        
</div>

</div>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="tile">
            <div class="tile-body">
                <h4 class="tile-title"><?php echo e(__('Product wise Daily Sale :')); ?>

                </h4>
                <?php if($daily_carts->count() > 0): ?>
                <p class="text-right h6">Date: <?php echo e(date('Y-m-d', strtotime("-1 days"))); ?> </p>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Food Name </th>
                            <th class="text-center"> Unit Price </th>
                            <th class="text-center"> Total Qty </th>
                            <th class="text-center"> Subtotal </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total =0.0; ?>
                        <?php $__currentLoopData = $daily_carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                            <td class="text-center">
                                <?php if($cart->product_attribute_id): ?>
                                <?php echo e(App\Models\Product::find($cart->product_id)->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->size); ?>)
                                <?php else: ?>
                                <?php echo e(App\Models\Product::find($cart->product_id)->name); ?>

                                <?php endif; ?>

                            </td>
                            <td class="text-center"><?php echo e(round( $cart->unit_price,0)); ?>

                                <?php echo e(config('settings.currency_symbol')); ?>

                            </td>
                            <td class="text-center"><?php echo e($cart->total_qty); ?></td>
                            <td class="text-center">
                                <?php echo e(round($cart->subtotal,0)); ?>

                                <?php echo e(config('settings.currency_symbol')); ?>

                            </td>
                        </tr>
                        <?php $total += $cart->subtotal ;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5">
                                <h4 class="text-right mb-0 ">Total Sale:
                                    <?php echo e(round( $total, 0)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </h4>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php else: ?>
                <p class="text-center p-5 h5">No Food Items has been sold out on
                    <?php echo e(date('Y-m-d', strtotime("-1 days"))); ?>

                </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/report/daily.blade.php ENDPATH**/ ?>