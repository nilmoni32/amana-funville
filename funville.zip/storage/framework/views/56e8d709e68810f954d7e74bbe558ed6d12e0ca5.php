

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfcomplimentarySales', [$start_date, $end_date])); ?>" class="btn btn-sm btn-dark"
            target="_blank"><i class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="#" class="btn btn-sm btn-info"><i
                class="fa fa-file-excel-o" style="font-size:17px;"></i></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <div class="row mb-4">
                    <div class="col-12 pt-3">
                        <form action="<?php echo e(route('admin.reports.getcomplimentarySales')); ?>" method="post"
                            class="form-inline justify-content-center">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-2">
                                <label>
                                    <span class="font-weight-bold pr-1">From Date :</span>
                                    <input type="text" name="start_date" class="form-control datetimepicker"
                                    value="<?php echo e(\Carbon\Carbon::parse($start_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <label class="font-bold">
                                    <span class="font-weight-bold pr-1">To Date :</span>
                                    <input type="text" name="end_date" class="form-control datetimepicker"
                                    value="<?php echo e(\Carbon\Carbon::parse($end_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2" name="btnProfitLoss">
                                Preview</button>
                        </form>
                    </div>
                </div>
                <?php if($complimentary_sales->count() > 0): ?>
                <div class="row mx-1 border p-3">              
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                            <tr>
                                <th class="text-center"> Receipt No </th>
                                <th class="text-center"> Date</th>
                                <th class="text-center"> Name </th>
                                <th class="text-center"> Quantity </th>
                                <th class="text-center"> Sales Cost</th>
                                <th class="text-center"> Remarks</th>
                            </tr>
                        </thead>                        
                        <tbody>
                            <?php $__currentLoopData = $complimentary_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($sale->order_number); ?></td>
                                <td class="text-center">
                                    <?php echo e(date("d-m-Y", strtotime($sale->order_date))); ?>

                                </td>
                                <td class="text-center"><?php echo e($sale->product_name); ?></td>
                                <td class="text-center"><?php echo e(round($sale->total_qty,2)); ?> </td>
                                <td class="text-center"><?php echo e(round($sale->salesCost,2)); ?> <?php echo e(config('settings.currency_symbol')); ?></td>
                                <td class="text-center"><?php echo e($sale->notes); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>                
                <?php else: ?>
                <p class="text-center p-5 h5"><?php echo e(__('No complimentary food items has been sold out by the specified date.')); ?>                    
                </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.datetimepicker').datetimepicker({
            timepicker:false,
            datepicker:true,        
            format: 'd-m-Y',              
        });
        $(".datetimepicker").attr("autocomplete", "off");

     $('#sampleTable').DataTable();
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/report/mis/complimentary/complimentaryview.blade.php ENDPATH**/ ?>