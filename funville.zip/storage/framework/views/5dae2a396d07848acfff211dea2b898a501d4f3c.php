
<?php $__env->startSection('title'); ?><?php echo e($pageTitle); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-th"></i> <?php echo e($pageTitle); ?> - <?php echo e($subTitle); ?></h1>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row user">
    <div class="col-md-3">
        <div class="tile p-0">
            <?php echo $__env->make('admin.ingredients.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col-md-9">
        <div class="tile">
            <div>
                <h3>Edit the damage ingredient details</h3>
            </div>
            <hr>
            <div class="tile-body mt-5">
                <form action="<?php echo e(route('admin.ingredient.damage.update')); ?>" method="POST" role="form">
                    <?php echo csrf_field(); ?>
                    <div class="tile-body">
                        <input type="hidden" name="damage_id" value="<?php echo e($damage->id); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="name">Ingredient Name</label>
                                    <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        placeholder="Enter Ingredient name" id="name" name="name"
                                        value="<?php echo e(old('name', $damage->name)); ?>" />
                                    <div class="invalid-feedback active">
                                        <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="quantity">Quantity</label>
                                    <input class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        placeholder="Enter Quantity" id="quantity" name="quantity"
                                        value="<?php echo e(old('quantity',  $damage->quantity)); ?>" />
                                    <div class="invalid-feedback active">
                                        <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row pb-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="unit">Measurement Unit</label>
                                    <select name="unit" id="unit" class="form-control">
                                        <option></option>
                                        <?php if($ingredient->measurement_unit == $ingredient->smallest_unit): ?>
                                        <option value=<?php echo e($ingredient->measurement_unit); ?> selected>
                                            <?php echo e($ingredient->measurement_unit); ?></option>
                                        <?php elseif($ingredient->smallest_unit == $damage->unit): ?>
                                        <option value=<?php echo e($ingredient->smallest_unit); ?> selected>
                                            <?php echo e($ingredient->smallest_unit); ?></option>
                                        <option value=<?php echo e($ingredient->measurement_unit); ?>>
                                            <?php echo e($ingredient->measurement_unit); ?>

                                            <?php elseif($ingredient->measurement_unit == $damage->unit): ?>
                                        <option value=<?php echo e($ingredient->measurement_unit); ?> selected>
                                            <?php echo e($ingredient->measurement_unit); ?></option>
                                        <option value=<?php echo e($ingredient->smallest_unit); ?>><?php echo e($ingredient->smallest_unit); ?>

                                        </option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label" for="reported_date">Report Date</label>
                                    <input type="text" class="form-control datetimepicker" name="reported_date"
                                        value="<?php echo e(\Carbon\Carbon::parse($damage->reported_date)->format('d-m-Y')); ?>"
                                        required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tile-footer">
                        <div class="row d-print-none mt-2">
                            <div class="col-12 text-right">
                                <button class="btn btn-success" type="submit"><i
                                        class="fa fa-fw fa-lg fa-check-circle"></i>Update
                                    Damage Ingredient</button>
                                <a class="btn btn-danger"
                                    href="<?php echo e(route('admin.ingredient.damage.index', $ingredient->id)); ?>"><i
                                        class="fa fa-fw fa-lg fa-arrow-left"></i>Go Back</a>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
    $('.datetimepicker').datetimepicker({
        timepicker:false,
        datepicker:true,        
        format: 'd-m-Y',              
    });
    $(".datetimepicker").attr("autocomplete", "off");

    $('#unit').select2({
                placeholder: "Select an measurement Unit",              
                multiple: false, 
                minimumResultsForSearch: -1,                        
             });

    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/ingredients/damages/edit.blade.php ENDPATH**/ ?>