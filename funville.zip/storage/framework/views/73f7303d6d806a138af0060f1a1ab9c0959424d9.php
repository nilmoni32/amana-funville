

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-database"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <form action="<?php echo e(route('admin.pos.orders.search')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3 mr-4">
                        <div class="col-4 mx-auto">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" placeholder="Search..." name="search">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit"><i class="fa fa-search"
                                            aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </div>

                        
                    </div>
                </form>
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> Order No </th>
                            <th class="text-center"> Order Date</th>
                            <th class="text-center"> Order Table No</th>
                            <th class="text-center"> Paid Amount </th>
                            <th class="text-center"> Payment Type </th>
                            <th class="text-center"> Order Status</th>
                            <th style=" min-width:50px;" class="text-center text-danger"><i class="fa fa-bolt"></i></th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->order_number); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                
                                <?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d-m-Y H:i:s')); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->order_tableNo); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e(round($order->grand_total,2)); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e(str_replace(',', ', ', $order->payment_method)); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->status); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <?php if($order->status == 'cancel' || $order->status == 'delivered'): ?>
                                    <a href="#" class="btn btn-sm btn-secondary"
                                        style="background-color:rgb(142, 177, 183); border-color:rgb(142, 177, 183);"
                                        disabled><i class="fa fa-edit"></i></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('admin.pos.orders.edit', $order->id)); ?>"
                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                </div>
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <a href="#" class="btn btn-sm btn-danger" data-toggle="modal"
                                        data-target="#userCartModal<?php echo e($order->id); ?>"><i
                                            class="fa fa-shopping-basket"></i></a>
                                    <!-- User Cart Modal -->
                                    <?php echo $__env->make('admin.sales.orders.includes.userCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    
                                </div>
                            </td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="pt-4 text-right">
    <?php echo e($orders->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    var orderId; // store order id when print button is clicked

    //JavaScript iterate through class elements and select the clicked print element
    var allprint = document.getElementsByClassName("allprint");    
    function getOrderId() {
    for(var i = 0; i < allprint.length; i++){
        if(this == allprint[i]){
            orderId = allprint[i].getAttribute('data-orderId'); 
        }
    }
    }
    [].forEach.call(allprint, function(a) {
    a.addEventListener('click', getOrderId);
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/sales/orders/index.blade.php ENDPATH**/ ?>