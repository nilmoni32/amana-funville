<div class="tile">
    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" role = "form" >
        
        <?php echo csrf_field(); ?>
        <h3 class="tile-title">Payment Settings via SSLCommerz for Cards/Net Banking</h3>
        <hr>
        <div class="tile-body">        
            <div class="form-group">
                <label class="control-label" for = "store_id">Store Id</label>
                <input class="form-control" type="text" placeholder="Enter SSLCommerz store id"  name = "store_id" id = "store_id" value = "<?php echo e(config('settings.store_id')); ?>">
            </div>
            <div class="form-group">
                <label class="control-label" for = "store_passwd">Store Password</label>
                <input class="form-control" type="text" placeholder="Enter SSLCommerz store password"  name = "store_passwd" id = "store_passwd" value = "<?php echo e(config('settings.store_passwd')); ?>">
            </div>
        </div>
        <div class="tile-footer">
            <div class="row d-print-none mt-2">
                <div class="col-12 text-right">
                    <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update Settings</button>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/settings/includes/payments.blade.php ENDPATH**/ ?>