<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\funville\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>