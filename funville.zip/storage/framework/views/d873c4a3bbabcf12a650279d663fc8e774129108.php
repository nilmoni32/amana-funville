

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-bar-chart"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <form action="<?php echo e(route('admin.orders.search')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3 mr-4">
                        <div class="app-search offset-xl-10 col-xl-2 offset-md-6 col-md-3 col-7">
                            <input class="app-search__input"
                                style="background:rgb(230, 230, 230); border: 1px solid rgb(201, 201, 201);"
                                type="search" placeholder="Search" name="search" />
                            <button type="submit" class="app-search__button" style="margin-right:-15px;">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> Order No </th>
                            <th class="text-center"> Order Date</th>
                            <th class="text-center"> Paid Amount </th>
                            <th class="text-center"> Payment Status </th>
                            <th class="text-center"> Payment Type </th>
                            <th class="text-center"> Order Status</th>
                            <th style="width:100px; min-width:100px;" class="text-center text-danger"><i
                                    class="fa fa-bolt"></i></th>
                            <th class="text-center">View Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->order_number); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                
                                <?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d-m-Y H:i:s')); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e(round($order->grand_total,0)); ?>

                            </td>
                            <?php if($order->payment_status): ?>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <span class="badge badge-success"><?php echo e(__('Paid')); ?></span>
                            </td>
                            <?php else: ?>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <span class="badge badge-danger"><?php echo e(__('Not paid')); ?></span>
                            </td>
                            <?php endif; ?>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->payment_method); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <?php echo e($order->status); ?>

                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <?php if($order->status == 'cancel'): ?>
                                    <a href="#" class="btn btn-sm btn-secondary"
                                        style="background-color:rgb(142, 177, 183); border-color:rgb(142, 177, 183);"
                                        disabled><i class="fa fa-edit"></i></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('admin.orders.edit', $order->id)); ?>"
                                        class="btn btn-sm btn-info"><i class="fa fa-edit"></i></a>
                                    <?php endif; ?>
                                    <?php if($order->status == 'delivered'): ?>
                                    <a href="<?php echo e(route('admin.orders.invoice', $order->id)); ?>"
                                        class="btn btn-sm btn-dark" target="_blank"><i class="fa fa-file-pdf-o"></i></a>
                                    <?php else: ?>
                                    <a href="#" class="btn btn-sm btn-secondary" disabled><i
                                            class="fa fa-file-pdf-o"></i></a>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="text-center" style="padding: 0.5rem; vertical-align: 0 ;">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <a href="#" class="btn btn-sm btn-primary" data-toggle="modal"
                                        data-target="#userModal<?php echo e($order->id); ?>"><i class="fa fa-user"></i></a>
                                    <!-- User Details Modal -->
                                    <?php echo $__env->make('admin.orders.includes.userDetail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <a href="#" class="btn btn-sm btn-danger" data-toggle="modal"
                                        data-target="#userCartModal<?php echo e($order->id); ?>"><i
                                            class="fa fa-shopping-basket"></i></a>
                                    <!-- User Cart Modal -->
                                    <?php echo $__env->make('admin.orders.includes.userCart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <a href="#" class="btn btn-sm btn-warning" data-toggle="modal"
                                        data-target="#userBankModal<?php echo e($order->id); ?>"><i class="fa fa-money"></i></a>
                                    <!-- User Bank Transaction Modal -->
                                    <?php echo $__env->make('admin.orders.includes.userBank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="pt-4 text-right">
    <?php echo e($orders->links()); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>