
<?php $__env->startSection('title'); ?><?php echo e($pageTitle); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-modx"></i> <?php echo e($pageTitle); ?> - <?php echo e($subTitle); ?></h1>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row user">
    <div class="col-md-3">
        <div class="tile p-0">
            <?php echo $__env->make('admin.recipes.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col-md-9">
        <div class="tile">
            <h3 class="tile-title">Add Ingredient for <?php echo e($recipe->product->name); ?></h3>
            <hr>
            <form action="<?php echo e(route('admin.recipe.ingredient.store')); ?>" method="POST" role="form">
                <?php echo csrf_field(); ?>
                <div class="tile-body">
                    <input type="hidden" name="recipe_id" value="<?php echo e($recipe->id); ?>">
                    <div class="row">
                        <div class="col-md-7 mx-auto">
                            <div class="form-group">
                                <label class="control-label" for="ingredient_name">Ingredient Name</label>
                                <select name="ingredient_name" id="ingredient_id"
                                    class="form-control <?php $__errorArgs = ['ingredient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option></option>
                                    <?php $__currentLoopData = App\Models\Ingredient::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($ingredient->id); ?>>
                                        <?php echo e($ingredient->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['ingredient_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7 mx-auto">
                            <div class="form-group">
                                <label class="control-label" for="measurement_unit">Measurement Unit</label>
                                <input name="measurement_unit" id="measure_unit"
                                    class="form-control <?php $__errorArgs = ['measurement_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=""
                                    readonly>
                                <?php $__errorArgs = ['measurement_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7 mx-auto">
                            <div class="form-group">
                                <label class="control-label" for="quantity">Quantity</label>
                                <input class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                    placeholder="Enter Quantity" id="quantity" name="quantity"
                                    value="<?php echo e(old('quantity')); ?>" />
                                <div class="invalid-feedback active">
                                    <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="tile-footer">
                    <div class="row d-print-none mt-2">
                        <div class="col-12 text-right">
                            <button class="btn btn-success" type="submit"><i
                                    class="fa fa-fw fa-lg fa-check-circle"></i>Save Ingredient</button>
                            <a class="btn btn-danger"
                                href="<?php echo e(route('admin.recipe.ingredient.index', $recipe->id)); ?>"><i
                                    class="fa fa-fw fa-lg fa-arrow-left"></i>Go Back</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    // getting CSRF Token from meta tag
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function () {
            $('#ingredient_id').select2({
                placeholder: "Select an ingredient",              
                multiple: false, 
                //minimumResultsForSearch: -1, 
                width: '100%',                        
             });

            //  $('#measure_unit').select2({
            //     placeholder: "Select an ingredient",              
            //     multiple: false, 
            //     minimumResultsForSearch: -1,                        
            //  });

            $('#ingredient_id').on('change',function(){
                if($(this).val() != "default"){ 
                    //getting the smallest measurement unit of the corresponding ingredient   
                    $.post("<?php echo e(route('admin.recipe.ingredient.getunit')); ?>", {
                        _token: CSRF_TOKEN,
                        ingredient_id: $(this).val(),                        
                    }).done(function(data) {
                        data = JSON.parse(data);
                        if(data.status == "success") { 
                            $('#measure_unit').val(data.small_unit); 
                        }
                    });             
                   
                }else{
                    $('#measure_unit').val('');
                }
            });

    });


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/recipes/ingredients/create.blade.php ENDPATH**/ ?>