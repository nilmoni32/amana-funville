<div class="dishes">
    <div class="container">
        <div class="row">
            <!-- Title Content Start -->
            <div class="col-sm-12 commontop text-center">
                <?php $category = App\Models\Category::where('slug', $slug_value)->first();?>
                <h4>Our <?php echo e($category->category_name); ?>


                </h4>
                <div class="divider style-1 center">
                    <span class="hr-simple left"></span>
                    <i class="icofont icofont-ui-press hr-icon"></i>
                    <span class="hr-simple right"></span>
                </div>
                <p><?php echo e(__('We are providing good food in rich taste with cheap rate. Please have a look of our cuisine food menu. Now you can have an idea about our food menu and have ready to taste certain foods of your heart desires. We are waiting for you with our all special dishes.')); ?>

                </p>
            </div>
            <!-- Title Content End -->
            <div class="col-sm-12">
                <?php
                // getting the products using many to many relatioship
                $products = $category->products;
                // only showing 5 products in the home page
                $top_5 = 1;
                ?>
                <div class="dish owl-carousel">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if( $top_5 == 5): ?>
                    <?php break; ?>;
                    <?php endif; ?>
                    
                    <?php $attributeCheck = in_array($product->id, $product->attributes->pluck('product_id')->toArray())
                    ?>
                    <?php if(!($attributeCheck) && $product->status): ?>
                    <div class="item">
                        <div class="box">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                                class="img-responsive" />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="caption">
                                <h4><?php echo e($product->name); ?></h4>
                                
                                <?php if($product->discount_price): ?>
                                <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->discount_price,0)); ?>

                                </p>
                                <span
                                    style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></span>
                                
                                <span>
                                    -<?php echo e(round(($product->price - $product->discount_price)*100/$product->price, 0)); ?>%</span>
                                <?php else: ?>
                                <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($product->price,0)); ?></p>
                                <?php endif; ?>
                                <span class="text-left px-1 py-1 d-block"><?php echo e($product->description); ?></span>
                            </div>
                            
                    </div>
                    <div class="hoverbox pb-2">
                        <?php
                        //Checking the product is added to cart or not
                        if(Auth::check()){ //Auth::check() to check if the user is logged in
                        // when logged user adds products to cart.
                        $cart = App\Models\Cart::where('user_id', Auth::id())
                        ->where('product_id', $product->id)
                        ->where('order_id', NULL)
                        ->where('has_attribute', 0)
                        ->first();
                        }else{
                        // when a guest adds product to cart.
                        $cart = App\Models\Cart::where('ip_address', request()->ip())
                        ->where('product_id', $product->id)
                        ->where('has_attribute', 0)
                        ->first();
                        }
                        ?>
                        <button class="btn btn-theme-alt btn-cart btn-block <?php echo e($cart ? 'display-none' : ''); ?>"
                            id="homeCartProductBtn<?php echo e($product->id); ?>" onclick="addToCart(<?php echo e($product->id); ?>, 0)">Add
                            to
                            Cart</button>
                        <p class="<?php echo e($cart ? '' : 'display-none'); ?> cart-msg" id="homeMsg<?php echo e($product->id); ?>">
                            Food is added to Cart</p>
                    </div>
                </div>
                <?php elseif($attributeCheck && $product->status): ?>
                
                <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="box">
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo asset('storage/'.$image->full); ?>" alt="image" title="<?php echo e($product->name); ?>"
                            class="img-responsive" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="caption">
                            <h4><?php echo e($product->name); ?>-(<?php echo e($attribute->size); ?>)</h4>
                            
                            <?php if($attribute->special_price): ?>
                            <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->special_price,0)); ?>

                            </p>
                            <span
                                style="text-decoration: line-through"><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></span>
                            
                            <span>
                                -<?php echo e(round(($attribute->price - $attribute->special_price)*100/$attribute->price, 0)); ?>%</span>
                            <?php else: ?>
                            <p><?php echo e(config('settings.currency_symbol')); ?>-<?php echo e(round($attribute->price,0)); ?></p>
                            <?php endif; ?>
                            <span class="text-left px-1 py-1 d-block"><?php echo e($product->description); ?></span>

                        </div>
                        
                </div>
                <div class="hoverbox pb-2">
                    <?php
                    //Checking the product is added to cart or not
                    if(Auth::check()){ //Auth::check() to check if the user is logged in
                    // when logged user adds products to cart.
                    $cart = App\Models\Cart::where('user_id', Auth::id())
                    ->where('product_id', $product->id)
                    ->where('product_attribute_id', $attribute->id)
                    ->where('order_id', NULL)
                    ->where('has_attribute', 1)
                    ->first();
                    }else{
                    // when a guest adds product to cart.
                    $cart = App\Models\Cart::where('ip_address', request()->ip())
                    ->where('product_id', $product->id)
                    ->where('product_attribute_id', $attribute->id)
                    ->where('has_attribute', 1)
                    ->first();
                    }
                    ?>
                    <button class="btn btn-theme-alt btn-cart btn-block <?php echo e($cart ? 'display-none' : ''); ?>"
                        id="homeCartSubProductBtn<?php echo e($attribute->id); ?>"
                        onclick="addToCart(<?php echo e($product->id); ?>, <?php echo e($attribute->id); ?>)">Add
                        to Cart</button>
                    <p class="<?php echo e($cart ? '' : 'display-none'); ?> cart-msg" id="homeSubMsg<?php echo e($attribute->id); ?>">
                        Food is added to Cart</p>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php
            //incrementing the counter to show only five product
            $top_5 += 1;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!--  view more button  -->
<div class="row pt-5">
    <div class="col-sm-12 col-xs-12">
        <div class="text-center pb-2">
            <a class="btn btn-theme-alt btn-wide" href='<?php echo e(route('products.index')); ?>'>view more <i
                    class="icofont icofont-curved-double-right"></i></a>
        </div>
    </div>
</div>
</div>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/homeslider.blade.php ENDPATH**/ ?>