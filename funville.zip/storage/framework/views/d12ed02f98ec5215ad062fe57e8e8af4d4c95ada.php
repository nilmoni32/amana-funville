<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfSingleSale', [$start_date, $end_date, $search_food])); ?>"
            class="btn btn-sm btn-dark" target="_blank"><i class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="<?php echo e(route('admin.reports.excelSingleSale', [$start_date, $end_date, $search_food])); ?>"
            class="btn btn-sm btn-info"><i class="fa fa-file-excel-o" style="font-size:17px;"></i></a>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <div class="row mb-4">
                    <div class="col-12 pt-3">
                        <form action="<?php echo e(route('admin.reports.singleSale')); ?>" method="post"
                            class="form-inline justify-content-center">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-2">
                                <label>
                                    <span class="font-weight-bold pr-1">Start Date :</span>
                                    <input type="text" name="start_date" class="datetimepicker"
                                        value="<?php echo e(\Carbon\Carbon::parse($start_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <label class="font-bold">
                                    <span class="font-weight-bold pr-1">End Date :</span>
                                    <input type="text" name="end_date" class="datetimepicker"
                                        value="<?php echo e(\Carbon\Carbon::parse($end_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <div class="form-group mb-2">
                                
                                <label>
                                    <span class="font-weight-bold pr-1">Food Name :</span>
                                    <input class="mr-3" type="text" name="search_food" value="<?php echo e($search_food); ?>"
                                        placeholder="Enter food name" required>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2" name="top20btn">
                                Item sale details</button>
                        </form>
                    </div>

                </div>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Date </th>
                            <th class="text-center"> Food Name </th>
                            <th class="text-center"> Unit Price </th>
                            <th class="text-center"> Total Qty </th>
                            <th class="text-center"> Subtotal </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $single_carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                            <td class="text-center"><?php echo e($cart->date); ?></td>
                            <td class="text-center">
                                <?php if($cart->product_attribute_id): ?>
                                <?php echo e(App\Models\Product::find($cart->product_id)->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->size); ?>)
                                <?php else: ?>
                                <?php echo e(App\Models\Product::find($cart->product_id)->name); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?php echo e(round( $cart->unit_price,0)); ?>

                                <?php echo e(config('settings.currency_symbol')); ?>

                            </td>
                            <td class="text-center"><?php echo e($cart->total_qty); ?></td>
                            <td class="text-center">
                                <?php echo e(round($cart->subtotal,0)); ?>

                                <?php echo e(config('settings.currency_symbol')); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
      $('.datetimepicker').datetimepicker({
        timepicker:false,
        datepicker:true,        
        format: 'd-m-Y',              
      });
      $(".datetimepicker").attr("autocomplete", "off");
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/report/singleitem.blade.php ENDPATH**/ ?>