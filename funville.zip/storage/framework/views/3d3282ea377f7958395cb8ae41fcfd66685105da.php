

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfstock', 'product')); ?>" class="btn btn-sm btn-dark"
            target="_blank"><i class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="#" class="btn btn-sm btn-info"><i
                class="fa fa-file-excel-o" style="font-size:17px;"></i></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <div class="row mb-4">
                    <div class="col-12 pt-3">
                        <form action="<?php echo e(route('admin.reports.getstock')); ?>" method="post"
                            class="form-inline justify-content-center">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group mx-sm-3 mb-2">  
                                <label class="form-check-label font-weight-bold pr-3" style="margin-top:-2px; for="inlineRadio2">Search Criteria :</label>                             
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="stockOption" id="inlineRadio2" value="product" checked>
                                    <label class="form-check-label font-weight-normal" for="inlineRadio2">Product</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="stockOption" id="inlineRadio1" value="category" required>
                                    <label class="form-check-label font-weight-normal" for="inlineRadio1">Product-category</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <select name='category' style='min-width:180px;' id="category" class="form-control font-weight-normal" disabled required>
                                        <?php $__currentLoopData = App\Models\Typeingredient::where('id','!=', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredienttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=""></option>
                                        <option value="<?php echo e($ingredienttype->id); ?>"><?php echo e($ingredienttype->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                     
                                    </select>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary mb-2" name="btnProfitLoss">
                                Preview</button>
                        </form>
                    </div>
                </div>
                <div class="row mx-1 border p-3">              
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                            <tr>
                                <th class="text-center"> # </th>
                                <th class="text-center"> Product Name </th>
                                <th class="text-center"> Qty</th>
                                <th class="text-center"> Threshold Qty</th>
                                <th class="text-center"> Unit </th>
                                <th class="text-center"> Amount </th>
                            </tr>
                        </thead>                        
                        <tbody>                           
                            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                                <td class="text-center"><?php echo e($ingredient->name); ?></td>
                                <td class="text-center"><?php echo e(round($ingredient->total_quantity,2)); ?></td>
                                <td class="text-center"><?php echo e(round($ingredient->alert_quantity,2)); ?></td>
                                <td class="text-center"><?php echo e($ingredient->measurement_unit); ?></td>
                                <td class="text-center"><?php echo e(round($ingredient->total_price, 2)); ?> <?php echo e(config('settings.currency_symbol')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#category').select2({
            placeholder: "Select a Category", 
        });
        //enable and disable select/dropdown 
        $('input:radio[name="stockOption"]').change(function() {
            if ($(this).val()=='product') {
                $('#category').attr('disabled', true);
            } 
            else if ($(this).val()=='category') {
                $('#category').attr('disabled', false);                
            }
        });

        $('.datetimepicker').datetimepicker({
            timepicker:false,
            datepicker:true,        
            format: 'd-m-Y',              
        });
        $(".datetimepicker").attr("autocomplete", "off");
        //setting dynamically ingredient type value for product category.
        $('#category').on('change', function() {
           // selecting the category radio button and change its value.
            $('input:radio[name="stockOption"][value="category"]').val(this.value);
        });

        $('#sampleTable').DataTable();
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/amanafunville.com/html/resources/views/admin/report/mis/stock/stockview.blade.php ENDPATH**/ ?>