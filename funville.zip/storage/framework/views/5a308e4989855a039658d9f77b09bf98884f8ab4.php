

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-paw"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="tile">
            <div class="tile-body">
                <h3 class="tile-title"><?php echo e(__('Add Service')); ?></h3>
                <form method="POST" action="<?php echo e(route('admin.services.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="control-label" for="title">Service Name</label>
                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                            placeholder="Enter Service Name" id="title" name="title" value="<?php echo e(old('title')); ?>" />
                        <div class="invalid-feedback active">
                            <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="icon">Service Icon</label>
                        <br />
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon1" value="fa-cutlery"
                                checked>
                            <label class="form-check-label" for="icon1"><i class="fa fa-cutlery"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon2" value="fa-gift">
                            <label class="form-check-label" for="icon2"><i class="fa fa-gift"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon3" value="fa-yelp">
                            <label class="form-check-label" for="icon3"><i class="fa fa-yelp"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon4"
                                value="fa-birthday-cake">
                            <label class="form-check-label" for="icon4"><i class="fa fa-birthday-cake"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon5" value="fa-slack">
                            <label class="form-check-label" for="icon5"><i class="fa fa-slack"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon6" value="fa-users">
                            <label class="form-check-label" for="icon6"><i class="fa fa-users"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon7" value="fa-university">
                            <label class="form-check-label" for="icon7"><i class="fa fa-university"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon8" value="fa-telegram">
                            <label class="form-check-label" for="icon8"><i class="fa fa-telegram"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon9" value="fa-slideshare">
                            <label class="form-check-label" for="icon9"><i class="fa fa-slideshare"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon10" value="fa-delicious">
                            <label class="form-check-label" for="icon10"><i class="fa fa-delicious"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon11" value="fa-empire">
                            <label class="form-check-label" for="icon11"><i class="fa fa-empire"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon12" value="fa-pagelines">
                            <label class="form-check-label" for="icon12"><i class="fa fa-pagelines"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon13" value="fa-truck">
                            <label class="form-check-label" for="icon13"><i class="fa fa-truck"></i></label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="icon" id="icon14" value="fa-meetup">
                            <label class="form-check-label" for="icon14"><i class="fa fa-meetup"></i></label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="description">Service Description</label>
                        <textarea name="description" id="description" rows="4" class="form-control" required></textarea>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-sm-12 text-right">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-fw fa-lg fa-check-circle"></i><?php echo e(__('Save Service')); ?>

                            </button>&nbsp;
                            <a class="btn btn-danger" href="<?php echo e(route('admin.services.index')); ?>"><i
                                    class="fa fa-fw fa-lg fa-arrow-left"></i><?php echo e(__('Go Back')); ?></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/services/create.blade.php ENDPATH**/ ?>