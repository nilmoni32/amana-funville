<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-bar-chart"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p class="h6 pt-2 pb-0">Edit Order Status</p>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="tile">
            <h6 class="tile-title mb-2"><?php echo e($subTitle); ?></h6>
            <span class="h6">[ Placed By: <?php echo e($order->user->name); ?> ]</span>
            <form action=" <?php echo e(route('admin.orders.update')); ?> " method="POST" role="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="tile-body mt-4">
                    <div class="form-group">
                        <label class="control-label" for="order_date"> Order Date:</label>
                        <input class="form-control" type="text" name="order_date" id="order_date"
                            value="<?php echo e(\Carbon\Carbon::parse($order->order_date)->format('d-m-Y H:i:s')); ?>" readonly>

                    </div>
                    <div class="form-group">
                        <label class="control-label" for="delivery_date"> Delivery Date:<span class="text-danger">
                                *</span></label>
                        <input class="form-control" type="text" name="delivery_date" id="delivery_date"
                            value="<?php echo e(date('d-m-Y', strtotime($order->delivery_date ))); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="status">Change Order Status:<span class="text-danger">*</span></label>
                        <select class="form-control custom-select mt-15 <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="status" name="status">
                            <option value="0">Select an Order Status</option>
                            <?php $__currentLoopData = ['pending','accept', 'cooking','packing', 'delivered', 'cancel']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($order_status); ?>" <?php echo e($order_status==$order->status ? "selected": ""); ?>>
                                <?php echo e($order_status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                    <div class="tile-footer text-right">
                        <button class="btn btn-primary" type="submit"><i
                                class="fa fa-fw fa-lg fa-check-circle"></i>Update Order Status</button>

                        &nbsp;&nbsp;&nbsp;<a class="btn btn-secondary" href="<?php echo e(route('admin.orders.index')); ?>"><i
                                class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
                    </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/orders/edit.blade.php ENDPATH**/ ?>