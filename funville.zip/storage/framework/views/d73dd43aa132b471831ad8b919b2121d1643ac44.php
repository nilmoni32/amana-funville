<!DOCTYPE html>
<html lang="en">

<body>
    <h3>Customer Details & Reservation Date:</h3>
    <p> Name: <?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?> <br /><br />
        Email: <?php echo e($user['email']); ?> <br /><br />
        Phone:<?php echo e($user['mobile']); ?> <br /><br />
        Date & Time : <?php echo e($user['appointment_dt']); ?> <br /><br />
    </p>
    <p>Dear Concern,</p>
    <p>I would like to make a reservation at Funville Restaurant dated on
        <?php echo e($user['appointment_dt']); ?>. So, please book a table for our
        <?php echo e($user['persons']); ?>

        members.</p>

    <p>Please contact me as soon as possible to confirm these arrangements. You can reach me using the contact
        information listed above.</p>
    <p>Thank you.</p>

    <p>Sincerely,</p>
    <p><?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?></p>


</body>

</html><?php /**PATH D:\xampp\htdocs\funville\resources\views/mail/email/reservation.blade.php ENDPATH**/ ?>