
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-dashboard"></i>&nbsp;Dashboard</h1>
  </div>
</div>

<div class="row"> 
  <div class="col-md-6 col-lg-3">
    <div class="widget-small primary coloured-icon">
      <i class="icon fa fa-delicious fa-3x"></i>
      <div class="info">
        <h5>Today KOT Sales</h5>
        <p><b>( <?php echo e(round(App\Models\Ordersale::whereDate('created_at', '=', Carbon\Carbon::today()->toDateString())->sum('grand_total'), 2)); ?> <?php echo e(config('settings.currency_symbol')); ?> )</b></p>
      </div>
    </div>
  </div>  
  <div class="col-md-6 col-lg-3">
    <div class="widget-small info coloured-icon">
      <i class="icon fa fa-shopping-basket fa-3x"></i>
      <div class="info">
        <h5>KOT Orders</h5>
        <p><b>( <?php echo e(App\Models\Ordersale::count()); ?> )</b></p>
      </div>
    </div>
  </div> 
  <div class="col-md-6 col-lg-3">
    <div class="widget-small warning coloured-icon">
      <i class="icon fa fa-users fa-3x"></i>
      <div class="info">
        <h5>Admin Users</h5>
        <p><b>( <?php echo e(App\Models\Admin::count()); ?> )</b></p>
      </div>
    </div>
  </div>
 <div class="col-md-6 col-lg-3">
  <div class="widget-small danger coloured-icon">
    <i class="icon fa fa-cutlery fa-3x"></i>
    <div class="info">
      <h4>Foods</h4>
      <p><b>(<?php echo e(App\Models\Product::count()); ?>)</b></p>
    </div>
  </div>
</div> 
</div>
<div class="row">
  <div class="col-md-6 col-lg-3">
    <div class="widget-small primary coloured-icon">
      <i class="icon fa fa-bar-chart fa-3x"></i>
      <div class="info">
        <h5>Today Online Sales</h5>
        <p><b>( <?php echo e(round(App\Models\Order::where('status', 'delivered')->whereDate('created_at', '=', Carbon\Carbon::today()->toDateString())->sum('grand_total'), 2)); ?> <?php echo e(config('settings.currency_symbol')); ?> )</b></p>
      </div>
    </div>
  </div>   
  <div class="col-md-6 col-lg-3">
    <div class="widget-small bg-info coloured-icon">
      <i class="icon fa fa-shopping-basket fa-3x"></i>
      <div class="info">
        <h5>Online Orders</h5>
        <p><b>( <?php echo e(App\Models\Order::count()); ?> )</b></p>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-lg-3">
    <div class="widget-small bg-success coloured-icon">
      <i class="icon fa fa-users fa-3x"></i>
      <div class="info">
        <h5>Online Customers</h5>
        <p><b>( <?php echo e(App\Models\User::count()); ?> )</b></p>
      </div>
    </div>
  </div>
  <div class="col-md-6 col-lg-3">
    <div class="widget-small bg-danger coloured-icon">
      <i class="icon fa fa-star fa-3x"></i>
      <div class="info">
        <h5>Ingredients</h5>
        <p><b>(<?php echo e(App\Models\Ingredient::count()); ?>)</b></p>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>