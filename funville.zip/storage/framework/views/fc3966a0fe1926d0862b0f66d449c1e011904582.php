<?php $__env->startSection('title', 'Food Menu'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Food Menu</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">Food Menu</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->

<!-- Food Menu Start -->
<div class="shop pb-5">
    <div class="container py-3">
        <div class="row">
            <div class="col-md-3">
                <!-- Left search Filter and Category Start -->
                <div class="left-side">
                    <h4><?php echo e(__('Funville Cuisine')); ?></h4>
                    <div class="search mt-3 px-3 pb-0">
                        <form action="<?php echo e(route('search')); ?>" class="form-horizontal search-icon" method='get'>
                            <div class="form-group">
                                <input name="search" value="" class="form-control" placeholder="Search Food"
                                    type="text">
                                <button type="submit" value="submit" class="btn"><i
                                        class="icofont icofont-search"></i></button>
                            </div>
                        </form>
                    </div>
                    <div class="list-group list-group-flush mt-0 mb-5 hidden-xs">
                        <a href="<?php echo e(route('categoryproduct.show', 'all' )); ?>"
                            class="list-group-item list-group-item-action active">
                            <img src="<?php echo e(asset('frontend')); ?>/images/dishes/all.jpg" width="60"
                                style="margin-right:15px;"><span><?php echo e(__('All Dishes')); ?></span>
                        </a>
                        <?php $__currentLoopData = App\Models\Category::orderBy('id', 'asc')->where('parent_id', '1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('categoryproduct.show', $parent->slug )); ?>"
                            class="list-group-item list-group-item-action">
                            <img src="<?php echo asset('storage/'.$parent->image); ?>" width="60"
                                style="margin-right:15px;"><span><?php echo e($parent->category_name); ?></span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <!-- Left search Filter and Category End -->
            </div>
            <div class="col-md-9">
                <!-- Title Content Start -->
                <div class="col-sm-12 commontop text-center mb-5">
                    <h4 class="mt-0">All Dishes</h4>
                    <div class="divider style-1 center">
                        <span class="hr-simple left"></span>
                        <i class="icofont icofont-ui-press hr-icon"></i>
                        <span class="hr-simple right"></span>
                    </div>
                </div>
                <!-- Title Content End -->
                <?php echo $__env->make('site.partials.productview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

    </div>
</div>
<!-- Shop End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/product/allproducts.blade.php ENDPATH**/ ?>