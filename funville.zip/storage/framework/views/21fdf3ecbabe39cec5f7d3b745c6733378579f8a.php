<div class="user-payment">
    <div class="table-responsive-md">
        <?php if(App\Models\Order::where('user_id', auth()->user()->id)->first()): ?>
        <div class="row">
            <div class="col-12">
                <?php $orders = App\Models\Order::orderBy('created_at', 'desc')->where('user_id',
                auth()->user()->id)->paginate(5); ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-entry">
                    <span class="order-id">Order ID: <?php echo e($order->order_number); ?></span>
                    <div class="item-content">
                        <div class="item-body">
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Food Name</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = App\Models\Cart::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php echo e($loop->index + 1); ?>

                                        </td>
                                        <td class="text-left" style="text-transform:capitalize">
                                            <img src="<?php echo e(asset('storage/'.$cart->product->images->first()->full)); ?>"
                                                title="<?php echo e($cart->product->name); ?>"
                                                class="img-responsive d-inline-block pr-2 rounded" width="70px" />
                                            <?php if($cart->has_attribute): ?>
                                            
                                            <?php echo e($cart->product->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->size); ?>)
                                            <?php else: ?>
                                            <?php echo e($cart->product->name); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td class="text-center">
                                            <?php echo e($cart->product_quantity); ?>

                                        </td>

                                        <td class="text-center" style="text-transform:capitalize">
                                            <?php if($cart->has_attribute): ?>
                                            
                                            
                                            <?php if(
                                            App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price): ?>
                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price,0)); ?>

                                            <?php else: ?>
                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->price,0)); ?>

                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($cart->product->discount_price): ?>
                                            <?php echo e(round($cart->product->discount_price,0)); ?>

                                            <?php else: ?>
                                            <?php echo e(round($cart->product->price,0)); ?>

                                            <?php endif; ?>
                                            <?php endif; ?>

                                        </td>
                                        <td class="text-center" style="text-transform:capitalize">
                                            <?php if($cart->has_attribute): ?>
                                            
                                            
                                            <?php if(
                                            App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price): ?>
                                            <?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->price *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($cart->product->discount_price): ?>
                                            <?php echo e($cart->product->discount_price *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e($cart->product->price  *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php if($order->status != 'cancel'): ?>
                            <p class="p-0 m-0"><strong class="ml-0">Status:</strong></p>
                            <div class="cart-status d-flex cart-status-direction mt-1">
                                <?php if($order->status == 'pending'): ?>
                                <div class="cart-flex-item-active">Pending</div>
                                <?php else: ?>
                                <div class="cart-flex-item-nonactive">Pending</div>
                                <?php endif; ?>
                                <?php if($order->status == 'accept'): ?>
                                <div class="cart-flex-item-active">Accept</div>
                                <?php else: ?>
                                <div class="cart-flex-item-nonactive">Accept</div>
                                <?php endif; ?>
                                <?php if($order->status == 'cooking'): ?>
                                <div class="cart-flex-item-active">Cooking</div>
                                <?php else: ?>
                                <div class="cart-flex-item-nonactive">Cooking</div>
                                <?php endif; ?>
                                <?php if($order->status == 'packing'): ?>
                                <div class="cart-flex-item-active">Packing</div>
                                <?php else: ?>
                                <div class="cart-flex-item-nonactive">Packing</div>
                                <?php endif; ?>
                                <?php if($order->status == 'delivered'): ?>
                                <div class="cart-flex-item-active">Delivered</div>
                                <?php else: ?>
                                <div class="cart-flex-item-nonactive">Delivered</div>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <p class="p-0 m-0"><strong class="ml-0">Status:</strong></p>
                            <div class="cart-status d-flex cart-status-direction mt-1">
                                <div class="cart-flex-item-cancel">Cancelled</div>
                            </div>
                            <?php endif; ?>

                        </div>
                        <div class="item-footer">
                            <p>
                                <strong class="ml-0">Expected
                                    Date:</strong><?php echo e(date('d-m-Y', strtotime($order->delivery_date ))); ?>

                                <strong>Grand Total:</strong><?php echo e(config('settings.currency_symbol')); ?>

                                <?php echo e(round($order->grand_total,0)); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="pt-4 text-center">
            <?php echo e($orders->links()); ?>

        </div>

        <?php else: ?>
        <div class="col-12 text-center">
            <h4 class="p-5">
                <?php echo e(__( 'No Transaction has been made' )); ?>

            </h4>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/user/includes/orders.blade.php ENDPATH**/ ?>