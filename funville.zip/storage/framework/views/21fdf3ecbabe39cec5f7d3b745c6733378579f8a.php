<div class="user-payment">
    <div class="table-responsive-md">
        <?php if(App\Models\Order::where('user_id', auth()->user()->id)->first()): ?>
        <div class="row">
            <div class="col-12">
                <?php $orders = App\Models\Order::orderBy('created_at', 'desc')->where('user_id',
                auth()->user()->id)->paginate(5); ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-entry">
                    <span class="order-id">Order ID: <?php echo e($order->order_number); ?></span>
                    <div class="item-content">
                        <div class="item-body">
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Food Name</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = App\Models\Cart::where('order_id', $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php echo e($loop->index + 1); ?>

                                        </td>
                                        <td class="text-left" style="text-transform:capitalize">
                                            <img src="<?php echo e(asset('storage/'.$cart->product->images->first()->full)); ?>"
                                                title="<?php echo e($cart->product->name); ?>" class="img-responsive pr-2 rounded"
                                                width="70px" />
                                            <?php if($cart->has_attribute): ?>
                                            
                                            <?php echo e(App\Models\ProductAttribute::find($cart->product_id)->product->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_id)->size); ?>)
                                            <?php else: ?>
                                            <?php echo e($cart->product->name); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td class="text-center">
                                            <?php if($cart->has_attribute): ?>
                                            <?php echo e($cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e($cart->product_quantity); ?>

                                            <?php endif; ?>
                                        </td>

                                        <td class="text-center" style="text-transform:capitalize">
                                            <?php if($cart->has_attribute): ?>
                                            
                                            
                                            <?php if( App\Models\ProductAttribute::find($cart->product_id)->special_price): ?>
                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_id)->special_price,0)); ?>

                                            <?php else: ?>
                                            <?php echo e(round(App\Models\ProductAttribute::find($cart->product_id)->price,0)); ?>

                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($cart->product->discount_price): ?>
                                            <?php echo e(round($cart->product->discount_price,0)); ?>

                                            <?php else: ?>
                                            <?php echo e(round($cart->product->price,0)); ?>

                                            <?php endif; ?>
                                            <?php endif; ?>

                                        </td>
                                        <td class="text-center" style="text-transform:capitalize">
                                            <?php if($cart->has_attribute): ?>
                                            
                                            
                                            <?php if( App\Models\ProductAttribute::find($cart->product_id)->special_price): ?>
                                            <?php echo e(App\Models\ProductAttribute::find($cart->product_id)->special_price *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e(App\Models\ProductAttribute::find($cart->product_id)->price *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php else: ?>
                                            <?php if($cart->product->discount_price): ?>
                                            <?php echo e($cart->product->discount_price *  $cart->product_quantity); ?>

                                            <?php else: ?>
                                            <?php echo e($cart->product->price  *  $cart->product_quantity); ?>

                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="item-footer">
                            <p>
                                <?php if($order->status == 'decline'): ?>
                                <span class="btn btn-warning text-dark text-capitalize"><?php echo e($order->status); ?></span>
                                <?php else: ?>
                                <span class="btn btn-success text-white text-capitalize"><?php echo e($order->status); ?></span>
                                <?php endif; ?>
                                <strong>Order Date:</strong><?php echo e($order->order_date); ?><strong>Grand
                                    Total:</strong><?php echo e(config('settings.currency_symbol')); ?>

                                <?php echo e(round($order->grand_total,0)); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="pt-4 text-center">
            <?php echo e($orders->links()); ?>

        </div>

        <?php else: ?>
        <div class="col-12 text-center">
            <h4 class="p-5">
                <?php echo e(__( 'No Transaction has been made' )); ?>

            </h4>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/user/includes/orders.blade.php ENDPATH**/ ?>