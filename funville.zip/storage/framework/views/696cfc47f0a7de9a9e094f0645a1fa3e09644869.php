

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfgetCustomerSales', [$start_date, $end_date, $client->id])); ?>" class="btn btn-sm btn-dark"
            target="_blank"><i class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="#" class="btn btn-sm btn-info"><i
                class="fa fa-file-excel-o" style="font-size:17px;"></i></a>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <div class="row mb-4">
                    <div class="col-12 pt-3">
                        <form action="<?php echo e(route('admin.reports.getCustomerSales')); ?>" method="post"
                            class="form-inline justify-content-center">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-2 mx-sm-3">
                                <label for="customer">
                                    <span class="font-weight-bold pr-1">Customer :</span>
                                    <select name='customer' style='width: 200px;' id="customer" class="form-control font-weight-normal" required>
                                        <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>                                       
                                    </select>
                                </label>
                            </div>
                            <div class="form-group mb-2">
                                <label>
                                    <span class="font-weight-bold pr-1">From Date :</span>
                                    <input type="text" name="start_date" class="form-control datetimepicker"
                                    value="<?php echo e(\Carbon\Carbon::parse($start_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <div class="form-group mx-sm-3 mb-2">
                                <label class="font-bold">
                                    <span class="font-weight-bold pr-1">To Date :</span>
                                    <input type="text" name="end_date" class="form-control datetimepicker"
                                    value="<?php echo e(\Carbon\Carbon::parse($end_date)->format('d-m-Y')); ?>" required>
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2" name="btnProfitLoss">
                                Preview</button>
                        </form>
                    </div>
                </div>
                <div class="row mx-1 py-2 border border-bottom-0">                               
                    <div class="col-12">
                        <div class="row pt-3 h6">
                            <div class="col-6 text-right">Customer Name :</div>
                            <div class="col-6 pl-0 text-left"><span><?php echo e($client->name); ?></span></div>                        
                        </div>
                    </div>                    
                    <div class="col-12">
                        <div class="row pt-1 h6">
                            <div class="col-6 text-right">Customer Mobile :</div>
                            <div class="col-6 pl-0 text-left"><span><?php echo e($client->mobile); ?></span></div>                        
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="row pt-1 h6">
                            <div class="col-6 text-right">Customer Reward Points :</div>
                            <div class="col-6 pl-0 text-left"><span><?php echo e($client->total_points); ?></span></div>                        
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="row pt-1 pb-2 h6">
                            <div class="col-6 text-right">Customer Address :</div>
                            <div class="col-6 pl-0 text-left"><span><?php echo e($client->address); ?></span></div>                        
                        </div>
                    </div>
                </div>       
                <div class="row mx-1 border p-3"> 
                    <?php if($customer_receipt->count() > 0): ?>
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                            <tr>
                                <th class="text-center"> # </th>
                                <th class="text-center"> ReceiptNo </th>
                                <th class="text-center"> PaidAmount </th>
                                <th class="text-center"> DiscountAmount (Reference)</th>
                                <th class="text-center"> DiscountAmount (Bonus Point)</th> 
                            </tr>
                        </thead>                        
                        <tbody>
                            <?php $__currentLoopData = $customer_receipt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                                <td class="text-center"><?php echo e($receipt->order_number); ?></td>
                                <td class="text-center"><?php echo e(round($receipt->grand_total,2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?></td>
                                <td class="text-center"><?php echo e(round($receipt->discount,2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?></td>
                                <td class="text-center"><?php echo e(round($receipt->reward_discount,2)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                         
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="col-12">
                    <p class="text-center p-5 h5"><?php echo e(__('No sales record by the specified date for the customer.')); ?>                    
                    </p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
   // CSRF Token
   var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function () {
        $('#customer').select2({
            //placeholder: "Select Customer",
            //select2-ajax
            ajax: { 
            url: "<?php echo e(route('admin.reports.getClients')); ?>",
            type: "post",
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                _token: CSRF_TOKEN,
                search: params.term // search term
                };
            },
            processResults: function (response) {
                return {
                results: response
                };
            },
            cache: true
            }       
        });

        $('.datetimepicker').datetimepicker({
            timepicker:false,
            datepicker:true,        
            format: 'd-m-Y',              
        });
        $(".datetimepicker").attr("autocomplete", "off");

     $('#sampleTable').DataTable();
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/report/mis/customersales/customersalesview.blade.php ENDPATH**/ ?>