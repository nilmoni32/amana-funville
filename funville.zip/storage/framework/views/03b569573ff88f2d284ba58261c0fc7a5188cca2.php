
<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-ils"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="tile">
            <h3 class="tile-title"><?php echo e($subTitle); ?></h3>
            <form action=" <?php echo e(route('admin.ingredienttypes.update')); ?> " method="POST" role="form"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="tile-body">
                    <div class="form-group">
                        <label class="control-label" for="name">Name<span class="text-danger"> *</span></label>
                        
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name"
                            id="name" value="<?php echo e(old('name', $targetCategory->name)); ?>">
                        <input type="hidden" name="id" value="<?php echo e($targetCategory->id); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="description">Description</label>
                        <textarea class="form-control" rows="4" name="description"
                            id="description"><?php echo e(old('description', $targetCategory->description)); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="parent">Parent Category<span class="text-danger"> *</span></label>
                        <select class="form-control custom-select mt-15 <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="parent" name="parent_id">
                            <option value="0">Select a parent category</option>
                            <?php $__currentLoopData = $ingredienttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredienttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($targetCategory->parent_id == $ingredienttype->id): ?>
                            <option value="<?php echo e($ingredienttype->id); ?>" selected><?php echo e($ingredienttype->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($ingredienttype->id); ?>"><?php echo e($ingredienttype->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="tile-footer">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update
                        Category</button>
                    &nbsp;&nbsp;&nbsp;<a class="btn btn-danger" href="<?php echo e(route('admin.ingredienttypes.index')); ?>"><i
                            class="fa fa-fw fa-lg fa-arrow-left"></i>Go Back</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/ingredient_types/edit.blade.php ENDPATH**/ ?>