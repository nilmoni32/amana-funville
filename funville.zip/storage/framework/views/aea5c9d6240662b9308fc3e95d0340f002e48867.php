<form class="form-online" action="<?php echo e(route('cart.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
    <div class="buttons">
        <button type="submit" class="btn btn-theme-alt btn-md">Add to Cart</button>
    </div>
</form><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/cartbutton.blade.php ENDPATH**/ ?>