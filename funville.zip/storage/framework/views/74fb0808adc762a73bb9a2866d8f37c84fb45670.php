<div class="tile">
    <form action="<?php echo e(route('admin.ingredient.update')); ?>" method="POST" role="form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h3 class="tile-title">Edit the ingredient details</h3>
        <hr>
        <div class="tile-body">
            <input type="hidden" name="ingredient_id" value="<?php echo e($ingredient->id); ?>">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="name">Name</label>
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                            placeholder="Edit Name" id="name" name="name"
                            value="<?php echo e(old('name', $ingredient->name)); ?>" />
                        <div class="invalid-feedback active">
                            <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="name">Alert Quantity</label>
                        <input class="form-control <?php $__errorArgs = ['alert_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                            placeholder="Enter Quantity threshold value" id="alert_quantity" name="alert_quantity"
                            value="<?php echo e(old('alert_quantity', $ingredient->alert_quantity)); ?>" />
                        <div class="invalid-feedback active">
                            <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['alert_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label" for="description">Description</label>
                <textarea name="description" id="description" rows="4" class="form-control"><?php echo e(old('description', $ingredient->description)); ?>

                </textarea>
            </div>
            <div class="row">
                <div class="col-md-3 text-center">
                    <?php if($ingredient->pic): ?>
                    <img src="<?php echo e(asset('/storage/images/'. $ingredient->pic)); ?>" width="80" id="beforeUpload">
                    <?php endif; ?>
                </div>
                <div class="col-md-9">
                    <div class="form-group">
                        <label class="control-label" for="name">Image</label>
                        <input type="file" name="pic" class="form-control <?php $__errorArgs = ['pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pic">
                        <div class="invalid-feedback active">
                            <i class="fa fa-exclamation-circle fa-fw"></i> <?php $__errorArgs = ['pic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="ingredienttypes">Ingredient Types</label>
                        <select name="typeingredient_id" id="ingredienttypes" class="form-control" multiple>
                            <?php $__currentLoopData = $ingredienttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredienttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $check = $ingredient->typeingredient_id == $ingredienttype->id ?
                            'selected' : '';
                            ?>
                            <option value="<?php echo e($ingredienttype->id); ?>" <?php echo e($check); ?>>
                                <?php echo e($ingredienttype->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="measurement_unit">Measurement Unit</label>
                        <?php
                        $val_kg = $ingredient->measurement_unit == 'Kg' ? 'selected' : '';
                        $val_L = $ingredient->measurement_unit == 'L' ? 'selected' : '';
                        $val_pcs = $ingredient->measurement_unit == 'pcs' ? 'selected' : '';
                        $val_bundle = $ingredient->measurement_unit == 'bundle' ? 'selected' : '';
                        ?>
                        <select name="measurement_unit" id="measurement_unit" class="form-control" multiple>
                            <option value="Kg" <?php echo e($val_kg); ?>>killogram</option>
                            <option value="L" <?php echo e($val_L); ?>>liter</option>
                            <option value="pcs" <?php echo e($val_pcs); ?>>pcs</option>
                            <option value="bundle" <?php echo e($val_bundle); ?>>bundle</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="smallest_unit">Smallest Measurement
                            Unit</label>
                        <?php
                        $chk_gm = $ingredient->smallest_unit == 'gm' ? 'selected' : '';
                        $chk_ml = $ingredient->smallest_unit == 'ml' ? 'selected' : '';
                        $chk_pcs = $ingredient->smallest_unit == 'pcs' ? 'selected' : '';
                        $chk_bundle = $ingredient->smallest_unit == 'bundle' ? 'selected' : '';
                        ?>
                        <select name="smallest_unit" id="smallest_unit" class="form-control" multiple>
                            <option value="gm" <?php echo e($chk_gm); ?>>gm</option>
                            <option value="ml" <?php echo e($chk_ml); ?>>ml</option>
                            <option value="pcs" <?php echo e($chk_pcs); ?>>pcs</option>
                            <option value="bundle" <?php echo e($chk_bundle); ?>>bundle</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="tile-footer">
            <div class="row d-print-none mt-2">
                <div class="col-12 text-right">
                    <button class="btn btn-success" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update
                        Ingredient</button>
                    <a class="btn btn-danger" href="<?php echo e(route('admin.ingredient.index')); ?>"><i
                            class="fa fa-fw fa-lg fa-arrow-left"></i>Go Back</a>
                </div>
            </div>
        </div>
    </form>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/ingredients/includes/general.blade.php ENDPATH**/ ?>