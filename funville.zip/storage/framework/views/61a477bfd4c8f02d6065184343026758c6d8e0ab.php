

<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-users"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('admin.reports.pdfdailytotal')); ?>" class="btn btn-sm btn-dark" target="_blank"><i
                class="fa fa-file-pdf-o" style="font-size:16px;"></i></a>
        <a href="<?php echo e(route('admin.reports.exceldailytotal')); ?>" class="btn btn-sm btn-info"><i class="fa fa-file-excel-o"
                style="font-size:17px;"></i></a>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="tile">
            <div class="tile-body">
                <h4 class="tile-title"><?php echo e(__('Daily Sale:')); ?>

                </h4>
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Date </th>
                            <th class="text-center"> Total </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daily_totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daysale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                            <td class="text-center"><?php echo e($daysale->date); ?></td>
                            <td class="text-center"><?php echo e(round( $daysale->subtotal,0)); ?>

                                <?php echo e(config('settings.currency_symbol')); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pt-4 text-right">
                    <?php echo e($daily_totals->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\funville\resources\views/admin/report/daytotal.blade.php ENDPATH**/ ?>