<div class="modal fade" id="userCartModal<?php echo e($order->id); ?>" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header justify-content-center border-bottom-0">
                <h5 class="modal-title text-right mt-3" id="exampleModalLabel"><i class="fa fa-shopping-basket"></i>
                    Customer Order Details
                </h5>
            </div>
            <div class="modal-body text-center">
                <p class="text-center h6 pb-2">[ Order Number:&nbsp;
                    <?php echo e($order->order_number); ?> ]</p>
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <th>#</th>
                        <th>Food Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                    </thead>
                    <tbody>
                        <?php $subtotal = 0; $cart_model = 'App\Models\Cart'; ?>
                        <?php if($order->status == 'delivered' || $order->status == 'cancel' ): ?>
                        <?php $cart_model = 'App\Models\Cartbackup';?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $cart_model::where('order_id',
                        $order->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td class="text-left" style="text-transform:capitalize">
                                <img src="<?php echo e(asset('storage/'.$cart->product->images->first()->full)); ?>"
                                    title="<?php echo e($cart->product->name); ?>" class="img-responsive pr-2 rounded"
                                    width="70px" />
                                <?php if($cart->has_attribute): ?>
                                
                                <?php echo e($cart->product->name); ?>-(<?php echo e(App\Models\ProductAttribute::find($cart->product_attribute_id)->size); ?>)
                                <?php else: ?>
                                <?php echo e($cart->product->name); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php echo e($cart->product_quantity); ?>

                            </td>
                            <td class="text-center" style="text-transform:capitalize">
                                <?php if($cart->has_attribute): ?>
                                
                                
                                <?php if(
                                App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price): ?>
                                <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price,0)); ?>

                                <?php $subtotal +=
                                App\Models\ProductAttribute::find($cart->product_attribute_id)->special_price *
                                $cart->product_quantity; ?>
                                <?php else: ?>
                                <?php echo e(round(App\Models\ProductAttribute::find($cart->product_attribute_id)->price,0)); ?>

                                <?php $subtotal +=
                                App\Models\ProductAttribute::find($cart->product_attribute_id)->price *
                                $cart->product_quantity; ?>
                                <?php endif; ?>
                                <?php else: ?>
                                <?php if($cart->product->discount_price): ?>
                                <?php echo e(round($cart->product->discount_price,0)); ?>

                                <?php $subtotal += $cart->product->discount_price * $cart->product_quantity;?>
                                <?php else: ?>
                                <?php echo e(round($cart->product->price,0)); ?>

                                <?php $subtotal += $cart->product->price * $cart->product_quantity; ?>
                                <?php endif; ?>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="4">
                                <p class="text-right mb-0 ">Subtotal:
                                    <?php echo e(round($subtotal,0)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <?php if(config('settings.tax_percentage')): ?>
                                <p class="text-right mb-0 ">Vat (<?php echo e(config('settings.tax_percentage')); ?>%):
                                    <?php echo e(round($subtotal* (config('settings.tax_percentage')/100),0)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <?php endif; ?>
                                <p class="text-right mb-0 ">Delivery
                                    Cost:
                                    <?php echo e(round(config('settings.delivery_charge'),0)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>
                                <p class="text-right mb-0 h6 mt-2">
                                    Grand Total:
                                    <?php echo e(round($order->grand_total,0)); ?>

                                    <?php echo e(config('settings.currency_symbol')); ?>

                                </p>

                            </td>
                        </tr>
                    </tbody>
                </table>


            </div>
            <div class=" modal-footer border-top-0">
                <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/orders/includes/userCart.blade.php ENDPATH**/ ?>