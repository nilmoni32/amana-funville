<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Funville')); ?></title>
  <!-- Main CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/css/jquery.datetimepicker.css" />
  <!-- Font-icon css-->
  <link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('backend')); ?>/css/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/images/favicon.ico')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/css/bootstrap-toggle.min.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/css/bootstrap-notifications.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/css/main.css" />
  <!--Jquery ui CSS -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/jqueryui/jquery-ui.min.css">

  <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="app sidebar-mini rtl" style="overflow-x: hidden;">
  <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  <main class="app-content">
    <?php echo $__env->yieldContent('content'); ?>
  </main>
  <!-- Essential javascripts for application to work-->
  <script src="<?php echo e(asset('backend')); ?>/js/jquery-3.2.1.min.js"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/popper.min.js"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/bootstrap.min.js"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/jquery.datetimepicker.full.min.js"></script>
  <script src="<?php echo e(asset('backend/js/plugins/select2.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/bootstrap-toggle.min.js"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/pusher.min.js"></script>
  <script src="<?php echo e(asset('backend')); ?>/js/main.js"></script>
  <!-- The javascript plugin to display page loading on top-->
  <script src="<?php echo e(asset('backend')); ?>/js/plugins/pace.min.js"></script>
  <!--Jquery ui script -->
  <script src="<?php echo e(asset('backend')); ?>/jqueryui/jquery-ui.min.js" type="text/javascript"></script>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH /var/www/amanafunville.com/html/resources/views/admin/app.blade.php ENDPATH**/ ?>