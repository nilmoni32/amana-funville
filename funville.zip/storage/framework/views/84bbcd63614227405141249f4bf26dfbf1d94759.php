<?php $__env->startSection('title', 'Homepage'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Payment Notification</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">Payment Notification</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->
<div class="mycart">
    <div class="container paycard">
        <div class="row">
            <div class="offset-md-2"></div>
            <div class="col-md-8 col-12 mb-5 text-center">
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-block bg-success text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('success')); ?></strong>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-error alert-block bg-danger text-white">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e(session('error')); ?></strong>
                </div>
                <?php endif; ?>
            </div>
            <div class="offset-md-2"></div>
        </div>
        <div class="row">
            <div class="col-12 pb-5">
                <h5 class="card-title mt-2 text-center mb-2">Order Number:
                    <?php echo e($order->order_number); ?></h5>
                <p class="text-center pt-0 font-weight-bold">
                </p>
            </div>
        </div>
        <div class="row">
            <div class="offset-md-2"></div>
            <div class="col-md-8 col-12 mb-5">
                <div class="row">
                    <div class="col-md-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header text-center">
                                Delivery Date & Address
                            </div>
                            <div class="card-body text-center">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($order->address); ?></td>
                                        </tr>
                                        <tr>
                                            <?php
                                            $time = strtotime($order->order_date);
                                            $date = date('Y-m-d', $time); ?>
                                            <td class="text-center">Order Date: <span class="ml-5"><?php echo e($date); ?></span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <?php
                                            $time = strtotime($order->delivery_date);
                                            $date = date('Y-m-d', $time); ?>
                                            <td class="text-center">Delivery Date: <span class="ml-5"><?php echo e($date); ?></span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-3">
                        <div class="card">
                            <div class="card-header text-center">
                                Order Summary
                            </div>
                            <div class="card-body text-center">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <td class="text-left">Subtotal</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(round(($order->grand_total - config('settings.delivery_charge')),0)); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">shipping</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(config('settings.delivery_charge')); ?></td>
                                        </tr>
                                        <tr>
                                            <td class="text-left">Order Total</td>
                                            <td class="text-left"><?php echo e(config('settings.currency_symbol')); ?>

                                                <?php echo e(round($order->grand_total,0)); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="offset-md-2"></div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/paynotify.blade.php ENDPATH**/ ?>