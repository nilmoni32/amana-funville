
<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>About Us</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(route('index')); ?>">HOME</a></li>
                <li class="list-inline-item"><a href="#">About Us</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->

<div class="container">
    <div class="row">
        <!-- Title Content Start -->
        <div class="col-sm-12 commontop text-center mb-2">
            <h4 class="text-center"><?php echo e(__('Welcome to Funville')); ?></h4>
            <div class="divider style-1 center">
                <span class="hr-simple left"></span>
                <i class="icofont icofont-ui-press hr-icon"></i>
                <span class="hr-simple right"></span>
            </div>
            <div class="row px-5">
                <div class="col-md-4 col-sm-12 text-center mb-3 pl-4">
                    <img src="<?php echo e(asset('/frontend')); ?>/images/funVill.png" alt="" class="img-responsive img-story">
                </div>
                <div class="col-md-8 col-sm-12 about">
                    <p class="text-left mt-3">
                        <?php echo e(__('Amana Funville restaurant features sophisticated interpretations of traditional fare that is
            accented with artistic touches, presenting one of the most unique dining experiences in Rajshahi. A
            combination of gracious service, inventive cuisine, stylish décor and stunning views ensure that
            the restaurant is a hit with both guests and locals alike. Using its panoramic city views for
            inspiration, the focal point of the restaurant is an incredible city view.')); ?> </p>
                </div>

            </div>

            <!-- Title Content End -->
            <div class="row">
                <div class="col-sm-12 col-xs-12 commontop text-center mb-5">
                    <h4 class="text-center"><?php echo e(__('Our Services')); ?></h4>
                    <div class="divider style-1 center">
                        <span class="hr-simple left"></span>
                        <i class="icofont icofont-ui-press hr-icon"></i>
                        <span class="hr-simple right"></span>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <?php $__currentLoopData = App\Models\Service::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12 service-item">
                    <i class="fa <?php echo e($service->icon); ?>"></i>
                    <div>
                        <h4><?php echo e($service->title); ?></h4>
                        <p class="ml-3"><?php echo e($service->description); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/pages/about.blade.php ENDPATH**/ ?>