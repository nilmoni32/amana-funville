<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
  <div class="app-sidebar__user">
    <div class="pl-2">
      <p class="app-sidebar__user-name"><?php echo e(Auth::guard('admin')->user()->name); ?></p>
      <?php if(Auth::user()->roles()->first()->name == 'admin'): ?>
      <p class="app-sidebar__user-designation"> <?php echo e(__('[ Administrator ]')); ?> </p>
      <?php elseif(Auth::user()->hasRole('order-control') && Auth::user()->hasRole('stock-control')): ?>
      <p class="app-sidebar__user-designation"> <?php echo e(__('[ Controller ]')); ?> </p>
      <?php elseif(Auth::user()->hasRole('order-control')): ?>
      <p class="app-sidebar__user-designation"> <?php echo e(__('[ Order Controller ]')); ?> </p>
      <?php elseif(Auth::user()->hasRole('stock-control')): ?>
      <p class="app-sidebar__user-designation"> <?php echo e(__('[ Inventory Controller ]')); ?> </p>
      <?php else: ?>
      <p class="app-sidebar__user-designation"> <?php echo e(__('[ Generic User ]')); ?> </p>
      <?php endif; ?>
    </div>
  </div>
  <ul class="app-menu">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('funville-dashboard')): ?>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.dashboard' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="app-menu__icon fa fa-dashboard"></i>
        <span class="app-menu__label">Dashboard</span>
      </a>
    </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-reports')): ?>
    <?php if(Route::currentRouteName() == 'admin.reports.ecom.profitloss' || 
    Route::currentRouteName() == 'admin.reports.ecom.getprofitloss' ||
    Route::currentRouteName() == 'admin.reports.ecom.cashregister' ||
    Route::currentRouteName() == 'admin.reports.ecom.getcashregister' ||    
    Route::currentRouteName() == 'admin.reports.top20' ||
    Route::currentRouteName() == 'admin.reports.getTop20'||
    Route::currentRouteName() == 'admin.reports.single' ||
    Route::currentRouteName() == 'admin.reports.singleSale'){
    $temp = 1;
    }else{
    $temp = 0;
    }
    ?>
    <li class="<?php echo e($temp ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa fa-braille"></i><span class="app-menu__label">Ecommerce Reports</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">        
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.ecom.profitloss' ||
                                     Route::currentRouteName() == 'admin.reports.ecom.getprofitloss' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.ecom.profitloss')); ?>">
            <i class="icon fa fa-circle-o"></i>Profit and Loss</a>
        </li>        
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.ecom.cashregister' ||
          Route::currentRouteName() == 'admin.reports.ecom.getcashregister' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.ecom.cashregister')); ?>">
            <i class="icon fa fa-circle-o"></i>Cash Register Wise Sales</a>
        </li>        
        
      </ul>
    </li>
    <?php if(Route::currentRouteName() == 'admin.reports.combined.profitLoss' ||
            Route::currentRouteName() == 'admin.reports.combined.getcombinedprofitLoss' ||
            Route::currentRouteName() == 'admin.reports.profitLoss' || 
            Route::currentRouteName() == 'admin.reports.getprofitloss' ||
            Route::currentRouteName() == 'admin.reports.cashRegister' ||
            Route::currentRouteName() == 'admin.reports.getCashRegister' ||
            Route::currentRouteName() == 'admin.reports.customerSales' ||
            Route::currentRouteName() == 'admin.reports.getCustomerSales' ||
            Route::currentRouteName() == 'admin.reports.complimentarySales' ||
            Route::currentRouteName() == 'admin.reports.getcomplimentarySales' ||
            Route::currentRouteName() == 'admin.reports.bonusPoint' ||
            Route::currentRouteName() == 'admin.reports.stock' ||
            Route::currentRouteName() == 'admin.reports.getstock'){
    $flag = 1;
    }else{
    $flag = 0;
    }
    ?>
    <li class="<?php echo e($flag ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-registered"></i><span class="app-menu__label">MIS Reports</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.combined.profitLoss' ||
          Route::currentRouteName() == 'admin.reports.combined.getcombinedprofitLoss' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.combined.profitLoss')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Combined Profit and Loss</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.profitLoss' ||
          Route::currentRouteName() == 'admin.reports.getprofitloss' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.profitLoss')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Profit and Loss</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.cashRegister' ||
          Route::currentRouteName() == 'admin.reports.getCashRegister' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.cashRegister')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Cash Register Wise Sales</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.customerSales' ||
          Route::currentRouteName() == 'admin.reports.getCustomerSales' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.customerSales')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Customer Wise Sales</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.bonusPoint' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.bonusPoint')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Customer Bonus Point</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.complimentarySales' || 
            Route::currentRouteName() == 'admin.reports.getcomplimentarySales' ? 'active' : ''); ?>" 
            href="<?php echo e(route('admin.reports.complimentarySales')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Complimentary Sales</a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.reports.stock' || 
          Route::currentRouteName() == 'admin.reports.getstock' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.reports.stock')); ?>">
            <i class="icon fa fa-dot-circle-o"></i>Stock Report</a>
        </li>              
      </ul>
    </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-orders')): ?>
    <?php if(Route::currentRouteName() == 'admin.sales.index' ||
    Route::currentRouteName() == 'admin.pos.orders.index' ||
    Route::currentRouteName() == 'admin.restaurant.sales.index'){
    $temp1 = 1;
    }else{
    $temp1 = 0;
    }
    ?>
    <li class="<?php echo e($temp1 ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-delicious"></i><span class="app-menu__label">KOT</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.restaurant.sales.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.restaurant.sales.index', 0)); ?>">
            <i class="app-menu__icon fa fa-calculator"></i>
            <span class="app-menu__label">KOT Food Management</span>
          </a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.pos.orders.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.pos.orders.index')); ?>">
            <i class="app-menu__icon fa fa-database"></i>
            <span class="app-menu__label">KOT Order Lists</span>
          </a>
        </li>
        <li>
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.sales.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.sales.index', 0)); ?>">
            <i class="app-menu__icon fa fa-calculator"></i>
            <span class="app-menu__label">KOT Checkout & Payment </span>
          </a>
        </li>
      </ul>
    </li>
    <li>
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.orders.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.orders.index')); ?>">
        <i class="app-menu__icon fa fa-bar-chart"></i>
        <span class="app-menu__label">Ecommerce Orders</span>
      </a>
    </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-stock')): ?>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.ingredient.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.ingredient.index')); ?>">
        <i class="app-menu__icon fa fa-th"></i>
        <span class="app-menu__label">Stock Ingredients</span></a>
    </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('all-admin-features')): ?>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.ingredienttypes.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.ingredienttypes.index')); ?>">
        <i class="app-menu__icon fa fa-ils"></i>
        <span class="app-menu__label">Ingredients Types</span></a>
    </li>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.ingredientunit.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.ingredientunit.index')); ?>">
        <i class="app-menu__icon fa fa-object-ungroup"></i>
        <span class="app-menu__label">Unit Measurement</span></a>
    </li>  
    <li>
      <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.complimentary.sales.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.complimentary.sales.index')); ?>">
        <i class="app-menu__icon fa fa-leaf"></i>
        <span class="app-menu__label">Complimentary POS</span>
      </a>
    </li>      
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.recipe.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.recipe.index')); ?>">
        <i class="app-menu__icon fa fa-modx"></i>
        <span class="app-menu__label">Recipes</span></a>
    </li>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.categories.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.categories.index')); ?>">
        <i class="app-menu__icon fa fa-tags"></i>
        <span class="app-menu__label">Food Category</span></a>
    </li>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.products.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.products.index')); ?>">
        <i class="app-menu__icon fa fa-cutlery"></i>
        <span class="app-menu__label">Food Menu</span></a>
    </li>
    <?php if(Route::currentRouteName() == 'admin.adduser.form' ||
    Route::currentRouteName() == 'admin.users.index' ){
    $temp2 = 1;
    }else{
    $temp2 = 0;
    }
    ?>
    <li class="<?php echo e($temp2 ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Manage Users</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.adduser.form' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.adduser.form')); ?>">
            <i class="app-menu__icon fa fa-user"></i>
            <span class="app-menu__label">Add User</span></a>
        </li>
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.users.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.users.index')); ?>">
            <i class="app-menu__icon fa fa-user"></i>
            <span class="app-menu__label">Manage Users & Roles</span></a>
        </li>
      </ul>
    </li>

    <?php if(Route::currentRouteName() == 'admin.districts.index' ||
    Route::currentRouteName() == 'admin.zones.index' ||
    Route::currentRouteName() == 'admin.zones.getall' ){
    $temp4 = 1;
    }else{
    $temp4 = 0;
    }
    ?>
    <li class="<?php echo e($temp4 ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-map-marker"></i><span class="app-menu__label">Area Coverage</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.districts.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.districts.index')); ?>">
            <i class="app-menu__icon fa fa-map-signs"></i>
            <span class="app-menu__label">Manage District</span>
          </a>
        </li>
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.zones.index' ||
          Route::currentRouteName() == 'admin.zones.getall' ? 'active' : ''); ?>" href="<?php echo e(route('admin.zones.index')); ?>">
            <i class="app-menu__icon fa fa-map-signs"></i>
            <span class="app-menu__label">Manage Area</span>
          </a>
        </li>
      </ul>
    </li>
    <?php if(Route::currentRouteName() == 'admin.services.create' ||
    Route::currentRouteName() == 'admin.services.index' ){
    $temp3 = 1;
    }else{
    $temp3 = 0;
    }
    ?>
    <li class="<?php echo e($temp3 ? 'treeview is-expanded' : 'treeview'); ?>">
      <a class="app-menu__item" href="#" data-toggle="treeview">
        <i class="app-menu__icon fa fa-paw"></i><span class="app-menu__label">Manage Services</span>
        <i class="treeview-indicator fa fa-angle-right"></i>
      </a>
      <ul class="treeview-menu">
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.services.create' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.services.create')); ?>">
            <i class="app-menu__icon fa fa-crosshairs"></i>
            <span class="app-menu__label">Add Services</span></a>
        </li>
        <li>
          
          <a class="treeview-item <?php echo e(Route::currentRouteName() == 'admin.services.index' ? 'active' : ''); ?>"
            href="<?php echo e(route('admin.services.index')); ?>">
            <i class="app-menu__icon fa fa-crosshairs"></i>
            <span class="app-menu__label">All Services</span></a>
        </li>
      </ul>
    </li>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.board.directors.index' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.board.directors.index')); ?>">
        <i class="app-menu__icon fa fa-podcast"></i>
        <span class="app-menu__label">Board of Directors</span></a>
    </li>
    <li>
      
      <a class="app-menu__item <?php echo e(Route::currentRouteName() == 'admin.settings' ? 'active' : ''); ?>"
        href="<?php echo e(route('admin.settings')); ?>">
        <i class="app-menu__icon fa fa-cogs"></i>
        <span class="app-menu__label">Settings</span></a>
    </li>

    <?php endif; ?>





  </ul>
</aside><?php /**PATH C:\xampp\htdocs\funville\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>