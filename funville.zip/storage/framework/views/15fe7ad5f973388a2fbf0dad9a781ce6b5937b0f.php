<?php $__env->startSection('title'); ?>

<?php echo e($pageTitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i>&nbsp;<?php echo e($pageTitle); ?></h1>
        <p><?php echo e($subTitle); ?></p>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <div class="row mb-4">
                    <div class="col-md-3 offset-md-3">
                        <select class="form-control" name="district" id="district">
                            <option selected='false'>Select District</option>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary" name="find" id="find"><i
                                class="fa fa-search align-baseline"></i>
                            Find Areas</button>
                    </div>
                </div>
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Area Name </th>
                            <th class="text-center"> Status </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1 ?>
                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" style="padding: 0.3rem; vertical-align: 0 ;"><?php echo e($i); ?>

                            </td>
                            <td class="text-center" style="padding: 0.3rem; vertical-align: 0 ;"><?php echo e($zone->name); ?>

                            </td>
                            <td class="text-center" style="padding: 0.3rem; vertical-align: 0 ;">
                                <input type="checkbox" data-toggle="toggle" data-on="Active" data-off="Inactive"
                                    <?php echo e($zone->status ? 'checked' : ''); ?> data-onstyle="primary" data-offstyle="secondary"
                                    data-id=<?php echo e($zone->id); ?> class="zoneStatus">
                            </td>
                        </tr>
                        <?php $i++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#sampleTable').DataTable();
        // getting zone data
        $('#find').on('click', function(){
            var distId = $("#district").val();           
            $.ajax({
                url: window.location.href="<?php echo e(url('/admin/districts/zones')); ?>" + "/"+ distId
            });
        });
        
       // changing the zone status
        $('body').on('change', '.zoneStatus', function(){
            var id = $(this).attr('data-id');
            if(this.checked){
                var status = 1;
            }else{
                var status = 0;
            }   
              
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            }); 

            jQuery.ajax({
                  url: "<?php echo e(url('/admin/districts/zones')); ?>",
                  method: 'post',
                  data: {
                    id: id,
                    status: status                    
                  },
                  success: function(result){                     
                     console.log(result.success);
                  }
            });
         

        }); 



    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/areas/zoneupdate.blade.php ENDPATH**/ ?>