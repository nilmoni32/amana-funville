<!-- jquery -->
<script src="<?php echo e(asset('frontend')); ?>/libs/jquery/jquery.min.js"></script>
<!-- jquery datetimepicker js -->
<script src="<?php echo e(asset('frontend')); ?>/js/jquery.datetimepicker.full.min.js"></script>
<!-- jquery Validate -->
<script src="<?php echo e(asset('frontend')); ?>/libs/jquery-validation/jquery.validate.min.js"></script>
<!-- popper js -->
<script src="<?php echo e(asset('frontend')); ?>/libs/popper/popper.min.js"></script>
<!-- bootstrap js -->
<script src="<?php echo e(asset('frontend')); ?>/libs/bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
<!-- owlcarousel js -->
<script src="<?php echo e(asset('frontend')); ?>/libs/owlcarousel2/owl.carousel.min.js"></script>
<!--inview js code-->
<script src="<?php echo e(asset('frontend')); ?>/libs/jquery.inview/jquery.inview.min.js"></script>
<!--CountTo js code-->
<script src="<?php echo e(asset('frontend')); ?>/libs/jquery.countTo/jquery.countTo.js"></script>
<!-- Animated Headlines js code-->
<script src="<?php echo e(asset('frontend')); ?>/libs/animated-headlines/animated-headlines.js"></script>
<!-- mb.YTPlayer js code-->
<script src="<?php echo e(asset('frontend')); ?>/libs/mb.YTPlayer/jquery.mb.YTPlayer.min.js"></script>
<!--internal js-->
<script src="<?php echo e(asset('frontend')); ?>/js/internal.js"></script>
<!--sticky header js-->
<script src="<?php echo e(asset('frontend')); ?>/js/sticky.js"></script>
<!--funville restaurant js-->
<script src="<?php echo e(asset('frontend')); ?>/js/funville.js"></script><?php /**PATH D:\xampp\htdocs\funville\resources\views/site/partials/scripts.blade.php ENDPATH**/ ?>