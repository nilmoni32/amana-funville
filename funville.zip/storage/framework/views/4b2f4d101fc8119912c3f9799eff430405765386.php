

<?php $errors = Session::get('error');
$info = Session::get('info');
$messages = Session::get('success');
$warnings = Session::get('warning');
?>

<?php if($errors): ?>
    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger alert-dismissible" role="alert">    
        <button type="button" class="close" data-dismiss="alert">x</button>
        <strong>Error!</strong><?php echo e($value); ?>

        </button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($messages): ?>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-success alert-dismissible" role="alert">    
        <button type="button" class="close" data-dismiss="alert">x</button>
        <strong>Success!</strong><?php echo e($value); ?>

        </button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($info): ?>
    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-info alert-dismissible" role="alert">    
        <button type="button" class="close" data-dismiss="alert">x</button>
        <strong>Info!</strong><?php echo e($value); ?>

        </button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($warnings): ?>
    <?php $__currentLoopData = $warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-warning alert-dismissible" role="alert">    
        <button type="button" class="close" data-dismiss="alert">x</button>
        <strong>Warning!</strong><?php echo e($value); ?>

        </button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /var/www/amanafunville.com/html/resources/views/admin/partials/flash.blade.php ENDPATH**/ ?>