<?php $__env->startSection('title'); ?><?php echo e($pageTitle); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-cutlery"></i> <?php echo e($pageTitle); ?> - <?php echo e($subTitle); ?></h1>
    </div>
</div>
<?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row user">
    <div class="col-md-3">
        <div class="tile p-0">
            <ul class="nav flex-column nav-tabs user-tabs">
                <li>
                    <a class="app-menu__item bg-white text-dark <?php echo e(Route::currentRouteName() == 'admin.products.edit' ? 'active' : ''); ?>"
                        href="<?php echo e(route('admin.products.edit', $product->id)); ?>">
                        <span class="app-menu__label">General</span>
                    </a>
                </li>
                <li class="treeview">
                    <a class="app-menu__item bg-white text-dark" href="#" data-toggle="treeview">
                        <span class="app-menu__label">Attributes</span>
                        <i class="treeview-indicator fa fa-angle-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li>
                            <a class="treeview-item bg-white text-dark"
                                href="<?php echo e(route('admin.products.attribute.index', $product->id)); ?>">List all
                                Attributes</a>
                        </li>
                        <li>
                            <a class="treeview-item bg-white text-dark"
                                href="<?php echo e(route('admin.products.attribute.create', $product->id)); ?>">Add Attribute</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <div class="col-md-9">
        <div class="tile mt-4">
            <div>
                <h3>List all Attributes for the current food menu</h3>
            </div>
            <div class="tile-body mt-5">
                <table class="table table-hover table-bordered" id="sampleTable">
                    <thead>
                        <tr>
                            <th class="text-center"> # </th>
                            <th class="text-center"> Product Name </th>
                            <th class="text-center"> Size </th>
                            <th class="text-center"> Price </th>
                            <th class="text-center"> Discount Price </th>
                            <th style="width:100px; min-width:100px;" class="text-center text-danger"><i
                                    class="fa fa-bolt"> </i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($attribute->id); ?></td>
                            <td class="text-center"><?php echo e($attribute->product->name); ?></td>
                            <td class="text-center"><?php echo e($attribute->size); ?></td>
                            <td class="text-center"><?php echo e($attribute->price); ?></td>
                            <td class="text-center"><?php echo e($attribute->special_price); ?></td>
                            <td class="text-center">
                                <div class="btn-group" role="group" aria-label="Second group">
                                    <a href="<?php echo e(route('admin.products.attribute.edit', $attribute->id)); ?>"
                                        class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('admin.products.attribute.delete', $attribute->id)); ?>"
                                        class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/admin/products/viewattribute.blade.php ENDPATH**/ ?>