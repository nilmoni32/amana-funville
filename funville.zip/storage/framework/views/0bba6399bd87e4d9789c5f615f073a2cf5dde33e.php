<?php $__env->startSection('title', 'Verify Code'); ?>
<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Start -->
<div class="bread-crumb">
    <div class="container">
        <div class="matter">
            <h2>Verify Code</h2>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="index.html">HOME</a></li>
                <li class="list-inline-item"><a href="#">Verify Code</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Breadcrumb End -->

<div class="container">
    <div class="row justify-content-center">
        <div class="offset-md-1"></div>
        <div class="col-md-10 col-12 my-5 text-center">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-block bg-success text-white">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(session('success')); ?></strong>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger alert-block bg-danger text-white">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(session('error')); ?></strong>
            </div>
            <?php endif; ?>
        </div>
        <div class="offset-md-1"></div>
    </div>
</div>

<div class="container mb-5 mt-5">
    <div class="row justify-content-center">
        <div class="col-sm-10 col-md-8">
            <div class="card mb-5 mt-5">
                <div class="card-header"><strong><?php echo e(__('Verify Code')); ?></strong></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('verify')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="verify_token"
                                class="col-md-4 col-form-label text-md-right"><?php echo e(__('Verification Code')); ?></label>

                            <div class="col-md-6">
                                <input id="verify_token" type="text"
                                    class="form-control <?php $__errorArgs = ['verify_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="verify_token"
                                    value="" required autofocus>

                                <?php $__errorArgs = ['verify_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <input type="submit" value="Verify" class="btn btn-theme btn-md btn-block"
                                    style="width:50%; font-weight:normal;" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\funville\resources\views/auth/verification.blade.php ENDPATH**/ ?>