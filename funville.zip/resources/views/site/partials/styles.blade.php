<link rel="shortcut icon" type="image/x-icon" href="{{ asset('frontend/images/favicon.ico') }}">
<!-- Bootstrap stylesheet -->
<link href="{{ asset('frontend') }}/libs/bootstrap-4.0.0-dist/css/bootstrap.min.css" rel="stylesheet">
<!-- icofont -->
<link href="{{ asset('frontend') }}/libs/icofont/css/icofont.css" rel="stylesheet" type="text/css" />
<!-- crousel css -->
<link href="{{ asset('frontend') }}/libs/owlcarousel2/assets/owl.carousel.min.css" rel="stylesheet" type="text/css" />
<!-- Animated Headlines css -->
<link href="{{ asset('frontend') }}/libs/animated-headlines/animated-headlines.css" rel="stylesheet" type="text/css" />
<!-- mb.YTPlayer css -->
<link href="{{ asset('frontend') }}/libs/mb.YTPlayer/css/jquery.mb.YTPlayer.min.css" rel="stylesheet" type="text/css" />
<!-- Theme Stylesheet -->
<link href="{{ asset('frontend') }}/css/style.css" rel="stylesheet" type="text/css" />