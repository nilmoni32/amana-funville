<?php 

/*
|--------------------------------------------------------------------------
| Admin Web Routes
|--------------------------------------------------------------------------
|
| Here is where Admin user can register web routes for this application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::group(['namespace' => 'Admin','prefix' => 'admin', 'as' => 'admin.'], function(){

    // We are adding a routes group to prefix all our admin routes with /admin. so that get route would be /admin/login.
    // we are adding a routes group to as with named route so that name route would be ('admin.login.post');
    // we are adding a routes group to namespace with controller so that controller name would be Admin\LoginController@showLoginForm.
    
    // admin login request
    Route::get('login', 'LoginController@showLoginForm')->name('login'); 
    Route::post('login', 'LoginController@login')->name('login.post');  
    Route::get('logout', 'LoginController@logout')->name('logout');  
    
    // admin password reset form display and email send
    Route::get('password/reset', 'ForgotPasswordController@showLinkRequestForm')->name('password.request');
    Route::post('password/email', 'ForgotPasswordController@sendResetLinkEmail')->name('password.email');
    // admin password reset
    Route::get('password/reset/{token}', 'ResetPasswordController@showResetForm')->name('password.reset');
    Route::post('password/reset', 'ResetPasswordController@reset')->name('password.update');

    // To block unauthoized incoming HTTP requests we use middleware.
    // also we have to put this route at the last. 
    // Protecting the dashboard route, so only authenticated admin can load the dashboard view.
    // here auth:admin is admin guard.
    Route::group(['middleware' => ['auth:admin']], function () {

        Route::group(['middleware' => ['can:funville-dashboard']], function () {        
            Route::get('/', function () {
                return view('admin.dashboard.index');
            })->name('dashboard');
        });


        Route::group(['middleware' => ['can:manage-orders']], function () { 
            // Ecommerce Order Management
            Route::group(['prefix' => 'orders'], function () {
                Route::get('/', 'OrderController@index')->name('orders.index');
                Route::get('/edit/{id}', 'OrderController@edit')->name('orders.edit');
                Route::post('/update', 'OrderController@update')->name('orders.update');
                // Route::get('/{order}/show', 'OrderController@show')->name('orders.show');
                Route::get('/search', 'OrderController@search')->name('orders.search');
                Route::get('/invoice/{id}', 'OrderController@generateInvoice')->name('orders.invoice');
            });
            //KOT route checkout and orderplacement and  customer print receipt
            Route::group(['prefix' => 'pos'], function(){
                Route::get('/sales/{id}', 'SalesController@index')->name('sales.index'); 
                //search products using table no.
                Route::get('/search', 'SalesController@search')->name('sales.search');
                //pos order place
                //Route::post('/orderplace', 'SalesController@orderplace')->name('sales.orderplace');
                Route::post('/orderupdate', 'SalesController@orderupdate')->name('sales.orderupdate');
                //ajax route for pos sales.           
                Route::post('/getfoods','SalesController@getFoods')->name('sales.getfoods');
                Route::post('/foods/addsales','SalesController@addToSales')->name('sales.addtosales');
                Route::post('/cart/update', 'SalesController@update')->name('sales.saleCartUpdate');
                Route::post('/cart/delete', 'SalesController@destroy')->name('sales.saleCartDelete');

                Route::post('/customer/mobile','SalesController@getMobileNo')->name('sales.customermobile');
                Route::post('/customer/info','SalesController@addCustomerInfo')->name('sales.customerInfo');
                Route::post('/discount/slab','SalesController@discountSlab')->name('sales.discountSlab');
                Route::post('/card/discount','SalesController@cardDiscount')->name('sales.card.discount'); 
                Route::post('/gpstar/discount','SalesController@gpStarDiscount')->name('sales.gpStarDiscount'); 
                //end of ajax route for pos sales.
            
            });

            //POS/KOT route for restaurant print receipt
            Route::group(['prefix' => 'kot'], function(){
                Route::get('/restaurant/{id}', 'PosRestaurantController@index')->name('restaurant.sales.index'); 
                //pos order place
                Route::post('/order-place', 'PosRestaurantController@orderplace')->name('restaurant.sales.orderplace');
                
                //ajax route for pos sales.           
                Route::post('/findfoods','PosRestaurantController@getFoods')->name('restaurant.sales.getfoods');
                Route::post('/findfoods/addsales','PosRestaurantController@addToSales')->name('restaurant.sales.addtosales');
                Route::post('/sale-cart/update', 'PosRestaurantController@update')->name('restaurant.sales.saleCartUpdate');
                Route::post('/sale-cart/delete', 'PosRestaurantController@destroy')->name('restaurant.sales.saleCartDelete');
                //end of ajax route for pos sales.
            
            });

            // // KOT route for restaurant--- is no more used.
            // Route::group(['prefix' => 'kot'], function(){
            //     Route::get('/food/management', 'KotRestaurantController@index')->name('restaurant.sales.index'); 
               
            //     //ajax route for KOT [pos sales].    
            //     Route::get('/table/getfoods/{id}', 'KotRestaurantController@getTableFoods')->name('restaurant.sales.gettablefoods'); 
            //     //add single food item to a table     
            //     Route::post('/findfoods','KotRestaurantController@getFoods')->name('restaurant.sales.getfoods');
            //     Route::post('/findfoods/addsales','KotRestaurantController@addToSales')->name('restaurant.sales.addtosales');
            //     Route::post('/sale-cart/update', 'KotRestaurantController@update')->name('restaurant.sales.saleCartUpdate');
            //     Route::post('/sale-cart/delete', 'KotRestaurantController@destroy')->name('restaurant.sales.saleCartDelete');
            //     //end of ajax route for KOT [ pos sales].
            // });


            //POS Orders Management [list of all pos orders]-- here POS=KOT
            Route::group(['prefix' => 'pos/orders'], function () {
                Route::get('/', 'PosOrderController@index')->name('pos.orders.index');
                Route::get('/edit/{id}', 'PosOrderController@edit')->name('pos.orders.edit');
                // Route::post('/update', 'PosOrderController@update')->name('pos.orders.update');
                Route::get('/search', 'PosOrderController@search')->name('pos.orders.search');
                //ajax method for update order status
                Route::post('/status', 'PosOrderController@orderStatusUpdate');                                          
                Route::post('/searchfoods','PosOrderController@getFoods')->name('pos.sales.getfoods');
                Route::post('/searchfoods/addsales','PosOrderController@addToSales')->name('pos.sales.addtosales');
                Route::post('/sale-cart/update', 'PosOrderController@update')->name('pos.sales.saleCartUpdate');
                Route::post('/sale-cart/delete', 'PosOrderController@destroy')->name('pos.sales.saleCartDelete');
                //end of ajax route for pos sales.
            });

        });

        // inventory controller rule
        Route::group(['middleware' => ['can:manage-stock']], function () { 

            //all Ingredient stock
            Route::group(['prefix' => 'ingredients'], function(){
                Route::get('/', 'IngredientController@index')->name('ingredient.index');
                Route::get('/create', 'IngredientController@create')->name('ingredient.create');
                Route::post('/store', 'IngredientController@store')->name('ingredient.store');
                Route::get('/edit/{id}', 'IngredientController@edit')->name('ingredient.edit');
                Route::post('/update', 'IngredientController@update')->name('ingredient.update');
                Route::get('/delete/{id}', 'IngredientController@delete')->name('ingredient.delete');                
            });

            // ingredient purchase or damage ajax route to autocomplete ingredient name.
            Route::post('/getingredients','IngredientController@getIngredients')->name('ingredient.getingredients');

            // ingredient purchase
            Route::group(['prefix' => 'ingredients/purchase'], function(){
                Route::get('/{id}', 'IngredientPurchaseController@index')->name('ingredient.purchase.index');
                Route::get('/{id}/create', 'IngredientPurchaseController@create')->name('ingredient.purchase.create');
                Route::post('/store', 'IngredientPurchaseController@store')->name('ingredient.purchase.store');
                Route::get('/{id}/edit', 'IngredientPurchaseController@edit')->name('ingredient.purchase.edit');
                Route::post('/update', 'IngredientPurchaseController@update')->name('ingredient.purchase.update');
                Route::get('/{id}/delete', 'IngredientPurchaseController@delete')->name('ingredient.purchase.delete');
            });
            

            // ingredient Damage
            Route::group(['prefix' => 'ingredients/damage'], function(){
                Route::get('/{id}', 'IngredientDamageController@index')->name('ingredient.damage.index');
                Route::get('/{id}/create', 'IngredientDamageController@create')->name('ingredient.damage.create');
                Route::post('/store', 'IngredientDamageController@store')->name('ingredient.damage.store');
                Route::get('/{id}/edit', 'IngredientDamageController@edit')->name('ingredient.damage.edit');
                Route::post('/update', 'IngredientDamageController@update')->name('ingredient.damage.update');
                Route::get('/{id}/delete', 'IngredientDamageController@delete')->name('ingredient.damage.delete');
            });

        });

        Route::group(['middleware' => ['can:manage-reports']], function () { 
            //start ecommerce reports            
            Route::get('/reports/ecom/profit-loss', 'ReportController@profitloss')->name('reports.ecom.profitloss');
            Route::post('/reports/ecom/profit-loss', 'ReportController@getprofitloss')->name('reports.ecom.getprofitloss'); 
            Route::get('/reports/ecom/cash-register', 'ReportController@cashregister')->name('reports.ecom.cashregister');
            Route::post('/reports/ecom/cash-register', 'ReportController@getcashregister')->name('reports.ecom.getcashregister');                         
            Route::get('/reports/single', 'ReportController@single')->name('reports.single');
            Route::post('/reports/single', 'ReportController@singleSale')->name('reports.singleSale');

            //pdf-reports
            Route::get('/reports/ecom/pdf/cash-register/{date1}/{date2}', 'ReportController@pdfgetcashregister')->name('reports.ecom.pdfgetcashregister');
            Route::get('/reports/ecom/pdf/profit-loss/{date1}/{date2}/{op}', 'ReportController@pdfgetprofitloss')->name('reports.ecom.pdfgetprofitloss');
            //Route::get('/reports/single/pdf/{date1}/{date2}/{search}', 'ReportController@pdfSingleSale')->name('reports.pdfSingleSale'); 

            //excel reports
            //Route::get('/reports/single/excel/{date1}/{date2}/{search}', 'ReportController@excelSingleSale')->name('reports.excelSingleSale');
            //end of ecommerce reports

            //MIS Reports            
            Route::get('/reports/combined/profit-loss', 'MISReportController@combinedprofitLoss')->name('reports.combined.profitLoss');
            Route::post('/reports/combined/profit-loss', 'MISReportController@getcombinedprofitLoss')->name('reports.combined.getcombinedprofitLoss');
            Route::get('/reports/profit-loss', 'MISReportController@profitLoss')->name('reports.profitLoss');
            Route::post('/reports/profit-loss', 'MISReportController@getprofitloss')->name('reports.getprofitloss');             
            Route::get('/reports/cash-register', 'MISReportController@cashRegister')->name('reports.cashRegister');
            Route::post('/reports/cash-register', 'MISReportController@getCashRegister')->name('reports.getCashRegister');
            Route::get('/reports/customer-sales', 'MISReportController@customerSales')->name('reports.customerSales');
            Route::post('/reports/customer-sales', 'MISReportController@getCustomerSales')->name('reports.getCustomerSales'); 
            Route::get('/reports/sales-complimentary', 'MISReportController@complimentarySales')->name('reports.complimentarySales');
            Route::post('/reports/sales-complimentary', 'MISReportController@getcomplimentarySales')->name('reports.getcomplimentarySales'); 
            Route::get('/reports/bonus-point', 'MISReportController@bonusPoint')->name('reports.bonusPoint');
            Route::get('/reports/stock', 'MISReportController@stock')->name('reports.stock');
            Route::post('/reports/stock', 'MISReportController@getstock')->name('reports.getstock');
            //ajax call to search customer via select2.
            Route::post('/reports/getclients/', 'MISReportController@getClients')->name('reports.getClients');
            //MIS PDF reports
            Route::get('/reports/combined/pdf/profit-loss/{date1}/{date2}', 'MISReportController@pdfcombinedgetprofitloss')->name('reports.pdfcombinedgetprofitloss');
            Route::get('/reports/pdf/cash-register/{date1}/{date2}', 'MISReportController@pdfgetCashRegister')->name('reports.pdfgetCashRegister');            
            Route::get('/report/pdf/customer-points/', 'MISReportController@pdfgetBonusPoints')->name('reports.pdfgetBonusPoints');
            Route::get('/report/pdf/customer-sales/{date1}/{date2}/{id}', 'MISReportController@pdfgetCustomerSales')->name('reports.pdfgetCustomerSales');
            Route::get('/reports/pdf/profit-loss/{date1}/{date2}/{op}', 'MISReportController@pdfgetprofitloss')->name('reports.pdfgetprofitloss');
            Route::get('/reports/pdf/sales-complimentary/{date1}/{date2}', 'MISReportController@pdfcomplimentarySales')->name('reports.pdfcomplimentarySales');
            Route::get('/report/pdf/stock/{op}', 'MISReportController@pdfstock')->name('reports.pdfstock');
        });

        //admin role
        Route::group(['middleware' => ['can:all-admin-features']], function () {  

            //  for all settings we will use one controller : SettingController
            Route::get('/settings', 'SettingController@index')->name('settings');
            Route::post('/settings', 'SettingController@update')->name('settings.update');
            // for manage Districts 
            Route::get('/districts', 'DistrictController@index')->name('districts.index');
            Route::post('/districts', 'DistrictController@districtUpdate');
            
            // for manage Zones 
            Route::get('/districts/zones', 'ZoneController@index')->name('zones.index');
            Route::get('/districts/zones/{id}', 'ZoneController@getZones')->name('zones.getall');
            Route::post('/districts/zones', 'ZoneController@zoneUpdate');

            // List categories route /admin/categories
            // Create category route /admin/categories/create : for creating category form
            // Store category route /admin/categories/store : storing the data into the database
            // Edit category route /admin/categories/{id}/edit : displaying the edit form by searching category id 
            // Update category route /admin/categories/update: update that category id row data 
            // Delete category route /admin/categories/{id}/delete : delete a particular category 

            Route::group(['prefix' => 'categories'], function(){

                Route::get('/', 'CategoryController@index')->name('categories.index');
                Route::get('/create', 'CategoryController@create')->name('categories.create');
                Route::post('/store', 'CategoryController@store')->name('categories.store');
                Route::get('/edit/{id}', 'CategoryController@edit')->name('categories.edit');
                Route::post('/update', 'CategoryController@update')->name('categories.update');
                Route::get('/delete/{id}', 'CategoryController@delete')->name('categories.delete');
            });

            Route::group(['prefix' => 'products'], function(){
                Route::get('/', 'ProductController@index')->name('products.index');
                Route::get('/create', 'ProductController@create')->name('products.create');
                Route::post('/store', 'ProductController@store')->name('products.store');
                Route::get('/{id}/edit', 'ProductController@edit')->name('products.edit');
                Route::post('/update', 'ProductController@update')->name('products.update');
                Route::get('/{id}/delete', 'ProductController@delete')->name('products.delete');
            });
            // creating the required routes for image uploading and delete using dropzone.
            Route::group(['prefix' => 'images'], function(){
                Route::post('/upload', 'ProductImageController@upload')->name('products.images.upload');
                Route::get('/{id}/delete', 'ProductImageController@delete')->name('products.images.delete');
            });
            
            Route::group(['prefix' => 'attributes'], function(){   
                // list all the attributes of the current product     
                Route::get('/{id}', 'ProductAttributeController@index')->name('products.attribute.index');
                // create attribute form for the current product
                Route::get('/{id}/create', 'ProductAttributeController@create')->name('products.attribute.create');
                // Add product attribute to the current product
                Route::post('/store', 'ProductAttributeController@store')->name('products.attribute.store');
                // edit product attribute to the current product
                Route::get('/{id}/edit', 'ProductAttributeController@edit')->name('products.attribute.edit');
                // update product attribute to the current product
                Route::post('/update', 'ProductAttributeController@update')->name('products.attribute.update');
                // Delete product attribute from the current product
                Route::get('/{id}/delete', 'ProductAttributeController@delete')->name('products.attribute.delete');
            });

            // Add Services
            Route::group(['prefix' => 'services'], function(){  
            Route::get('/create', 'ServiceController@create')->name('services.create'); 
            Route::post('/store', 'ServiceController@store')->name('services.store');
            Route::get('/all', 'ServiceController@index')->name('services.index'); 
            Route::get('/{id}/edit','ServiceController@edit')->name('services.edit');
            Route::post('/update', 'ServiceController@update')->name('services.update');
            Route::get('/{id}/delete', 'ServiceController@delete')->name('services.delete');
            });

            //Ingredient unit measurement
            Route::group(['prefix' => 'ingredient-units'], function(){
                Route::get('/', 'IngredientUnitController@index')->name('ingredientunit.index');
                Route::get('/create', 'IngredientUnitController@create')->name('ingredientunit.create');
                Route::post('/store', 'IngredientUnitController@store')->name('ingredientunit.store');
                Route::get('/edit/{id}', 'IngredientUnitController@edit')->name('ingredientunit.edit');
                Route::post('/update', 'IngredientUnitController@update')->name('ingredientunit.update');
                Route::get('/delete/{id}', 'IngredientUnitController@delete')->name('ingredientunit.delete');
            });

            //Ingredient Types
            Route::group(['prefix' => 'ingredient-types'], function(){
                Route::get('/', 'IngredientTypesController@index')->name('ingredienttypes.index');
                Route::get('/create', 'IngredientTypesController@create')->name('ingredienttypes.create');
                Route::post('/store', 'IngredientTypesController@store')->name('ingredienttypes.store');
                Route::get('/edit/{id}', 'IngredientTypesController@edit')->name('ingredienttypes.edit');
                Route::post('/update', 'IngredientTypesController@update')->name('ingredienttypes.update');
                Route::get('/delete/{id}', 'IngredientTypesController@delete')->name('ingredienttypes.delete');
            });
            
            //Recipe
            Route::group(['prefix' => 'recipe'], function(){
                Route::get('/', 'RecipeController@index')->name('recipe.index');
                Route::get('/create', 'RecipeController@create')->name('recipe.create');
                Route::post('/store', 'RecipeController@store')->name('recipe.store');
                Route::get('/edit/{id}', 'RecipeController@edit')->name('recipe.edit');
                Route::post('/update', 'RecipeController@update')->name('recipe.update');
                Route::get('/delete/{id}', 'RecipeController@delete')->name('recipe.delete');
            });

            //Recipe Ingredients
            Route::group(['prefix' => 'recipe/ingredients'], function(){
                Route::get('/{id}', 'RecipeIngredientController@index')->name('recipe.ingredient.index');
                Route::get('/{id}/create', 'RecipeIngredientController@create')->name('recipe.ingredient.create');
                Route::post('/store', 'RecipeIngredientController@store')->name('recipe.ingredient.store');
                Route::get('/edit/{id}', 'RecipeIngredientController@edit')->name('recipe.ingredient.edit');
                Route::post('/update', 'RecipeIngredientController@update')->name('recipe.ingredient.update');
                Route::get('/delete/{id}', 'RecipeIngredientController@delete')->name('recipe.ingredient.delete');
                //ajax route for get smallest unit measurement
                Route::post('/getunit','RecipeIngredientController@getunit')->name('recipe.ingredient.getunit');
            });

            //Payment Gateways
            Route::group(['prefix' => 'payment/gw'], function(){
                Route::get('/', 'PaymentGWController@index')->name('payment.gw.index');
                Route::get('/create', 'PaymentGWController@create')->name('payment.gw.create');
                Route::post('/store', 'PaymentGWController@store')->name('payment.gw.store');
                Route::get('/edit/{id}', 'PaymentGWController@edit')->name('payment.gw.edit');
                Route::post('/update', 'PaymentGWController@update')->name('payment.gw.update');
                Route::get('/delete/{id}', 'PaymentGWController@delete')->name('payment.gw.delete');
            });  
            
            //GP Star discount
            Route::group(['prefix' => 'gpstar/discount'], function(){
                Route::get('/', 'GpStarController@index')->name('gpstar.index');
                Route::get('/create', 'GpStarController@create')->name('gpstar.create');
                Route::post('/store', 'GpStarController@store')->name('gpstar.store');
                Route::get('/edit/{id}', 'GpStarController@edit')->name('gpstar.edit');
                Route::post('/update', 'GpStarController@update')->name('gpstar.update');
                Route::get('/delete/{id}', 'GpStarController@delete')->name('gpstar.delete');
            });
            

            //Complimentary sales route for restaurant.
            
            Route::group(['prefix' => 'complimentary'], function(){
                Route::get('/sales', 'ComplimentarySaleController@index')->name('complimentary.sales.index'); 
                //order place
                Route::post('/order-place', 'ComplimentarySaleController@orderplace')->name('complimentary.sales.orderplace');
                
                //ajax route.           
                Route::post('/findfoods','ComplimentarySaleController@getFoods')->name('complimentary.sales.getfoods');
                Route::post('/findfoods/addsales','ComplimentarySaleController@addToSales')->name('complimentary.sales.addtosales');
                Route::post('/sales/update', 'ComplimentarySaleController@update')->name('complimentary.sales.saleCartUpdate');
                Route::post('/sales/delete', 'ComplimentarySaleController@destroy')->name('complimentary.sales.saleCartDelete');
                //end of ajax route.
            });


        });
        //super admin role.
        Route::group(['middleware' => ['can:super-admin']], function () {  
            
            // Add Users  
            Route::get('/adduser', 'AddUserController@showAddUserForm')->name('adduser.form'); 
            Route::post('/adduser', 'AddUserController@saveUser')->name('adduser.save'); 
            // Users Role  
            Route::get('/role/users', 'RoleUserController@index')->name('users.index');
            Route::get('/role/users/{id}/edit','RoleUserController@edit')->name('users.edit');
            Route::post('/role/users', 'RoleUserController@update')->name('users.update');
            Route::get('/role/users/{id}', 'RoleUserController@destroy')->name('users.destroy');
            // Route::resource('/role/users', 'RoleUserController', ['except' => ['show','create', 'store']]);           

            //Discount Refrences
            Route::group(['prefix' => 'directors'], function(){
                Route::get('/', 'DirectorController@index')->name('board.directors.index');
                Route::get('/create', 'DirectorController@create')->name('board.directors.create');
                Route::post('/store', 'DirectorController@store')->name('board.directors.store');
                Route::get('/edit/{id}', 'DirectorController@edit')->name('board.directors.edit');
                Route::post('/update', 'DirectorController@update')->name('board.directors.update');
                Route::get('/delete/{id}', 'DirectorController@delete')->name('board.directors.delete');
            });


        });


        
    });
    

});
