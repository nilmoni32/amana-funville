<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;

class PagesController extends Controller
{
    /**
     * viewing the homepage of funville
     */
    public function index(){
        
        return view('site.pages.homepage');
    }

    public function about(){
        $order_no = '#'.(100000 + auth()->user()->id);
       
        return view('site.pages.about', compact('order_no'));
    }

    public function reservation(){

        return view('site.pages.reservation');
    }

    public function contact(){

        return view('site.pages.contact');
    }
    


}
