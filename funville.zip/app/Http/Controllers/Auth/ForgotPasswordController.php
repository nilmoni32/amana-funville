<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use App\Models\User;
use App\Mail\OtpMailable;
use App\Sms\SendCode;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    public function postforgot(Request $request){
        
        $validated = request()->validate([
            // 'email' => 'required|email|exists:users', 
            'phone_number' =>  'required|regex:/(01)[3-9]{1}(\d){8}/|max:11',  
            ]);  
  
        //finding the user with email verification code.
        $user = User::where('phone_number', $validated['phone_number'])->first();

        if(!$user->is_token_verified){

            if(session()->has('error') && session()->get('error') !== ''){
                session()->flash('error', '');
            }
            return redirect()->back()->with('error', 'User account has not been activated. Please activate first.');
        }
        else{
            //setting the eamil token.
            $user->update([ 
                 'verify_token' => mt_rand(10000,99999),                  
                ]);
            
            // sending token to phone            
            SendCode::sendCode($user->phone_number, $user->verify_token);
            
            //   sending mail to mailable class OtpMailable for the user with it's email id
            // \Mail::to($user->email)->send(new OtpMailable($user)); 
            
            if(session()->has('success') && session()->get('success') !== ''){
                session()->flash('success', '');
            }

            return redirect('verifytoken')->with('success', 'Please check your Phone to get the OTP to reset your password');
        }
        
    }
}
