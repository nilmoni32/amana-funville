<?php

namespace App\Sms;

class SendCode{

    public static function sendCode($mobile, $code){   
                                 
        // $nexmo = app('Nexmo\Client');
        // $nexmo->message()->send([
        //     'to'   => '+880'. (int) $mobile,
        //     'from' => 'Amana Funville',
        //     'text' => 'Verification Code:' . $code,
        // ]);  


       // send message to mobile number  
       
       $post_url = 'https://portal.smsinbd.com/smsapi/' ;  
                  
       $post_values = array( 
       'api_key' => 'b3c6b0eda3b46d9878df961d4c1c6b07d6cf886d',
       'type' => 'text',  // unicode or text
       'senderid' => '8801552146120',
       'contacts' => '880'. (int) $mobile,
       'msg' => 'Verification Code: ' . $code,
       'method' => 'api'
       );
       
       $post_string = "";
        foreach( $post_values as $key => $value )
            { $post_string .= "$key=" . urlencode( $value ) . "&"; }
            $post_string = rtrim( $post_string, "& " );
                  
                 
            $request = curl_init($post_url);  
                curl_setopt($request, CURLOPT_HEADER, 0);  
                curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($request, CURLOPT_POST, 1);  
                curl_setopt($request, CURLOPT_POSTFIELDS, $post_string); 
                curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE);  
                $post_response = curl_exec($request);  
                curl_close ($request);  
 
    }

}