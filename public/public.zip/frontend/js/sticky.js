$(function() {
    // Run it on page-loaded
    stickyHeader();
    //  sticky header
    $(window).scroll(stickyHeader);
});

function stickyHeader() {
    if ($(window).scrollTop()) {
        $("header div.sticky").addClass("black");
    } else {
        $(" header div.sticky").removeClass("black");
    }
}
