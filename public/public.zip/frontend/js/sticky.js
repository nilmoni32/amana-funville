//  sticky header
$(window).on("scroll", function() {
    if ($(window).scrollTop()) {
        $("header div.sticky").addClass("black");
    } else {
        $(" header div.sticky").removeClass("black");
    }
});
